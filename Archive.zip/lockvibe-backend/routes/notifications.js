const express = require("express");
const router = express.Router();
const Notification = require("../models/Notification");
const { auth } = require("../middleware/auth");

// GET /api/notifications - Fetch unread notifications for the authenticated user
router.get("/", auth, async (req, res) => {
  try {
    const notifications = await Notification.find({ 
      user_id: req.user.id, 
      read: false 
    }).sort({ createdAt: -1 }); // Sort by newest first
    res.json({ message: "Notifications fetched successfully", data: notifications });
  } catch (error) {
    console.error("Fetch notifications error:", error.stack);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// PATCH /api/notifications/read - Mark all notifications as read for the user
router.patch("/read", auth, async (req, res) => {
  try {
    await Notification.updateMany(
      { user_id: req.user.id, read: false },
      { read: true }
    );
    res.json({ message: "Notifications marked as read" });
  } catch (error) {
    console.error("Mark notifications read error:", error.stack);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

module.exports = router;