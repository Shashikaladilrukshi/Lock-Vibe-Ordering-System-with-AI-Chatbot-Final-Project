const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const { auth, adminOnly } = require('../middleware/auth');

// POST /api/orders - Place a new order
router.post('/', auth, async (req, res) => {
  const { products, shipping_address } = req.body;

  if (!products || !Array.isArray(products) || products.length === 0) {
    return res.status(400).json({ message: 'Products array is required' });
  }

  try {
    let total_amount = 0;
    const orderProducts = [];

    for (const item of products) {
      const { product_id, quantity } = item;
      if (!product_id || !quantity || quantity < 1) {
        return res.status(400).json({ message: 'Invalid product or quantity' });
      }

      const product = await Product.findById(product_id);
      if (!product) {
        return res.status(404).json({ message: `Product ${product_id} not found` });
      }
      if (product.stock < quantity) {
        return res.status(400).json({ message: `Insufficient stock for ${product.name}` });
      }

      total_amount += product.price * quantity;
      orderProducts.push({ product_id, quantity, price: product.price });

      product.stock -= quantity;
      await product.save();
    }

    const order = await Order.create({
      customer_id: req.user.id,
      products: orderProducts,
      total_amount,
      shipping_address: shipping_address || {},
    });

    res.status(201).json({ message: 'Order placed successfully', data: order });
  } catch (error) {
    console.error('Order creation error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/orders/report?date_range=daily or monthly - Sales reports (admin only)
// MOVED BEFORE /:id
router.get('/report', auth, adminOnly, async (req, res) => {
  const { date_range } = req.query;

  try {
    let startDate, endDate;
    if (date_range === 'daily') {
      startDate = new Date();
      startDate.setHours(0, 0, 0, 0); // Start of today
      endDate = new Date(); // Now
    } else if (date_range === 'monthly') {
      startDate = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
      endDate = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
    } else {
      return res.status(400).json({ message: 'Invalid date_range parameter. Use "daily" or "monthly"' });
    }

    console.log('Querying orders from', startDate, 'to', endDate);

    const orders = await Order.aggregate([
      { $match: { created_at: { $gte: startDate, $lte: endDate } } },
      {
        $group: {
          _id: { $dateToString: { format: date_range === 'daily' ? '%Y-%m-%d' : '%Y-%m', date: '$created_at' } },
          total_sales: { $sum: '$total_amount' },
          order_count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    console.log('Raw aggregation result:', orders);

    res.json({
      message: 'Sales report fetched successfully',
      data: {
        report: date_range,
        results: orders.map(o => ({ date: o._id, total_sales: o.total_sales, order_count: o.order_count })),
        total: orders.reduce((sum, o) => sum + o.total_sales, 0)
      }
    });
  } catch (error) {
    console.error('Sales report error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/orders/:id - Fetch order details
// MOVED AFTER /report
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('products.product_id', 'name description');
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.customer_id.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json({ message: 'Order fetched successfully', data: order });
  } catch (error) {
    console.error('Order fetch error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/orders - User order history (query with customer_id)
router.get('/', auth, async (req, res) => {
  const { customer_id } = req.query;

  try {
    if (customer_id && customer_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied' });
    }

    const query = customer_id ? { customer_id } : { customer_id: req.user.id };
    const orders = await Order.find(query).sort({ created_at: -1 })
      .populate('products.product_id', 'name description');
    res.json({ message: 'Order history fetched successfully', data: orders });
  } catch (error) {
    console.error('Order history error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/orders/:id - Update order status (admin only)
router.patch('/:id', auth, adminOnly, async (req, res) => {
  const { status } = req.body;

  if (!status || !['pending', 'shipped', 'delivered'].includes(status)) {
    return res.status(400).json({ message: 'Valid status is required (pending, shipped, delivered)' });
  }

  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    order.status = status;
    await order.save();
    res.json({ message: 'Order status updated successfully', data: order });
  } catch (error) {
    console.error('Order update error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;