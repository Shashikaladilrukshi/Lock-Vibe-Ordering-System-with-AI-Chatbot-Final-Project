const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { auth, adminOnly } = require('../middleware/auth');

// GET /api/products - Fetch products (public, with filters)
router.get('/', async (req, res) => {
  const { category, price_min, price_max, inStock, new: isNew, sort, page = 1, limit = 12 } = req.query;

  try {
    const query = {};

    if (category) query.category = category;
    if (price_min || price_max) {
      query.price = {};
      if (price_min) query.price.$gte = Number(price_min);
      if (price_max) query.price.$lte = Number(price_max);
    }
    if (inStock === 'true') query.stock = { $gt: 0 };
    if (isNew === 'true') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      query.created_at = { $gte: thirtyDaysAgo };
    }

    let sortOption = { created_at: -1 };
    if (sort === 'price-low') sortOption = { price: 1 };
    if (sort === 'price-high') sortOption = { price: -1 };

    const skip = (Number(page) - 1) * Number(limit);
    const products = await Product.find(query)
      .sort(sortOption)
      .skip(skip)
      .limit(Number(limit))
      .populate('supplier_id', 'name contact_email');

    console.log('Query:', query, 'Sort:', sortOption, 'Page:', page, 'Limit:', limit);
    res.json({ message: 'Products fetched successfully', data: products });
  } catch (error) {
    console.error('Product list error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/products/:id - Fetch single product (public)
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('supplier_id', 'name contact_email');
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product fetched successfully', data: product });
  } catch (error) {
    console.error('Product fetch error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;