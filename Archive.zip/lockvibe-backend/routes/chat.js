const express = require('express');
const OpenAI = require('openai');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Payment = require('../models/Payment');
const Supplier = require('../models/Supplier');
const User = require('../models/User');
const SupplierOrder = require('../models/SupplierOrder');
const { auth } = require('../middleware/auth');

const router = express.Router();


const token = process.env.GITHUB_TOKEN;
const endpoint = 'https://models.inference.ai.azure.com';
const modelName = 'gpt-4o';

if (!token) {
  console.error('GITHUB_TOKEN is missing from environment variables');
  process.exit(1); // Exit if token is missing to avoid runtime errors
}

const client = new OpenAI({ baseURL: endpoint, apiKey: token });

// POST /api/chat - Handle all chatbot queries (auth required)
router.post('/', auth, async (req, res) => {
  const { message } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ message: 'Yo, fam, send me a valid message to chat about!' });
  }

  try {
    const userId = req.user.id;
    console.log('User ID from token:', userId);

    // Build context from DB with individual try-catch for each query
    let products, orders, payments, suppliers, user, supplierOrders, dailySales, monthlySales;

    try {
      products = await Product.find({}).limit(10);
      console.log('Products fetched:', products.length);
    } catch (err) {
      console.error('Error fetching products:', err.stack);
      products = [];
    }

    try {
      orders = await Order.find({ customer_id: userId }).populate('products.product_id', 'name');
      console.log('Orders fetched:', orders.length);
    } catch (err) {
      console.error('Error fetching orders:', err.stack);
      orders = [];
    }

    try {
      payments = await Payment.find({ customer_id: userId }).populate('order_id', 'total_amount');
      console.log('Payments fetched:', payments.length);
    } catch (err) {
      console.error('Error fetching payments:', err.stack);
      payments = [];
    }

    try {
      suppliers = await Supplier.find({}).populate('products.product_id', 'name');
      console.log('Suppliers fetched:', suppliers.length);
    } catch (err) {
      console.error('Error fetching suppliers:', err.stack);
      suppliers = [];
    }

    try {
      user = await User.findById(userId);
      console.log('User fetched:', user ? user.email : 'Not found');
    } catch (err) {
      console.error('Error fetching user:', err.stack);
      user = null;
    }

    try {
      supplierOrders = await SupplierOrder.find({}).populate('supplier_id', 'name');
      console.log('Supplier orders fetched:', supplierOrders.length);
    } catch (err) {
      console.error('Error fetching supplier orders:', err.stack);
      supplierOrders = [];
    }

    try {
      dailySales = await Order.aggregate([
        { $match: { created_at: { $gte: new Date(new Date().setDate(new Date().getDate() - 1)) } } },
        { $group: { _id: null, total: { $sum: '$total_amount' }, count: { $sum: 1 } } }
      ]);
      console.log('Daily sales calculated:', dailySales);
    } catch (err) {
      console.error('Error calculating daily sales:', err.stack);
      dailySales = [];
    }

    try {
      monthlySales = await Order.aggregate([
        { $match: { created_at: { $gte: new Date(new Date().setMonth(new Date().getMonth() - 1)) } } },
        { $group: { _id: null, total: { $sum: '$total_amount' }, count: { $sum: 1 } } }
      ]);
      console.log('Monthly sales calculated:', monthlySales);
    } catch (err) {
      console.error('Error calculating monthly sales:', err.stack);
      monthlySales = [];
    }

    const context = {
      products: products.map(p => ({ id: p._id, name: p.name, price: p.price.toString(), description: p.description, stock: p.stock })),
      orders: orders.map(o => ({
        id: o._id,
        status: o.status,
        total: o.total_amount.toString(),
        products: o.products
          .map(p => (p.product_id ? p.product_id.name : 'Unknown Product'))
          .filter(name => name)
      })),
      payments: payments.map(p => ({ id: p._id, order_id: p.order_id ? p.order_id._id : 'Unknown', status: p.status, amount: (p.amount / 100).toString() })),
      suppliers: suppliers.map(s => ({ id: s._id, name: s.name, products: s.products.map(p => ({ name: p.product_id ? p.product_id.name : 'Unknown', stock: p.stock_provided })) })),
      user: user ? { id: user._id, name: user.name, email: user.email, address: user.address || 'Not set' } : null,
      supplierOrders: supplierOrders.map(so => ({ id: so._id, supplier: so.supplier_id ? so.supplier_id.name : 'Unknown', products: so.products.map(p => ({ id: p.product_id, quantity: p.quantity_requested })), status: so.status })),
      dailySales,
      monthlySales
    };

    // System prompt with explicit instructions, updated to use Rs instead of $
    const systemPrompt = `
      You’re Grok 3, a chill, helpful AI for an online door lock store. Respond casually with "Yo, fam" vibes, keeping it fun and concise. Use this context:
      - Products: ${JSON.stringify(context.products)}
      - Orders: ${JSON.stringify(context.orders)}
      - Payments: ${JSON.stringify(context.payments)}
      - Suppliers: ${JSON.stringify(context.suppliers)}
      - User: ${JSON.stringify(context.user)}
      - Supplier Orders: ${JSON.stringify(context.supplierOrders)}
      - Daily Sales: ${context.dailySales.length ? context.dailySales[0].total + ' Rs, ' + context.dailySales[0].count + ' orders' : 'No sales today'}
      - Monthly Sales: ${context.monthlySales.length ? context.monthlySales[0].total + ' Rs, ' + context.monthlySales[0].count + ' orders' : 'No sales this month'}

      Handle these question types:
      1. User Profile: "What’s my address?", "What’s my name?" - Use User data.
      2. Products: "What locks do you have?", "How much is Smart Lock Pro?" - List or find from Products.
      3. Orders: "What’s my order status?", "Did my lock ship?" - Check Orders by user.
      4. Payments: "Did my payment go through?", "How much did I pay?" - Use Payments.
      5. Suppliers: "Who supplies Smart Lock Pro?", "What suppliers you got?" - Check Suppliers.
      6. Supplier Orders: "What’s the status of supplier orders?", "Any shipments coming?" - Use Supplier Orders.
      7. Sales Reports: "How much did we make today?", "What’s monthly sales?" - Use Daily/Monthly Sales.
      8. General: "What’s up with my account?", "Tell me about my last order!" - Mix data as needed.

      If Orders is empty for "order status" questions, say "Yo, fam, no orders yet—time to grab some locks!" Otherwise, list them. Answer only with context data—no guessing!
    `;

    // Call GPT-4o
    const response = await client.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
      model: modelName,
      temperature: 1.0,
      max_tokens: 1000
    });

    const aiResponse = response.choices[0].message.content;

    res.json({ message: 'Chat handled, fam!', data: { response: aiResponse } });
  } catch (error) {
    console.error('Chat route error:', error.stack);
    res.status(500).json({ message: 'Server error, fam—something’s off!', error: error.message });
  }
});

module.exports = router;