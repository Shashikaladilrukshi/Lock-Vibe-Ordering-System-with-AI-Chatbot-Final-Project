const express = require('express');
const router = express.Router();
const Supplier = require('../models/Supplier');
const Product = require('../models/Product');
const { auth, adminOnly } = require('../middleware/auth');

// POST /api/suppliers - Add a new supplier (admin only)
router.post('/', auth, adminOnly, async (req, res) => {
  const { name, contact_email, phone, address, products } = req.body;

  if (!name || !contact_email || !products || !Array.isArray(products)) {
    return res.status(400).json({ message: 'Name, contact email, and products array are required' });
  }

  try {
    // Validate products
    for (const item of products) {
      const { product_id, stock_provided } = item;
      if (!product_id || !stock_provided || stock_provided < 0) {
        return res.status(400).json({ message: 'Invalid product_id or stock_provided' });
      }
      const product = await Product.findById(product_id);
      if (!product) {
        return res.status(404).json({ message: `Product ${product_id} not found` });
      }
    }

    const supplier = await Supplier.create({
      name,
      contact_email,
      phone,
      address: address || {},
      products
    });

    // Update product stock
    for (const item of products) {
      await Product.findByIdAndUpdate(item.product_id, {
        $inc: { stock: item.stock_provided }
      });
    }

    res.status(201).json({ message: 'Supplier added successfully', data: supplier });
  } catch (error) {
    console.error('Supplier creation error:', error.stack);
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Supplier with this email already exists' });
    }
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/suppliers - List all suppliers (admin only)
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const suppliers = await Supplier.find()
      .populate('products.product_id', 'name description price')
      .sort({ created_at: -1 });
    res.json({ message: 'Suppliers fetched successfully', data: suppliers });
  } catch (error) {
    console.error('Supplier list error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/suppliers/:id - Fetch supplier details (admin only)
router.get('/:id', auth, adminOnly, async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id)
      .populate('products.product_id', 'name description price');
    if (!supplier) {
      return res.status(404).json({ message: 'Supplier not found' });
    }
    res.json({ message: 'Supplier fetched successfully', data: supplier });
  } catch (error) {
    console.error('Supplier fetch error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/suppliers/:id - Update supplier details (admin only)
router.patch('/:id', auth, adminOnly, async (req, res) => {
  const { name, contact_email, phone, address, products } = req.body;

  if (!name && !contact_email && !phone && !address && !products) {
    return res.status(400).json({ message: 'At least one field must be provided to update' });
  }

  try {
    const supplier = await Supplier.findById(req.params.id);
    if (!supplier) {
      return res.status(404).json({ message: 'Supplier not found' });
    }

    // Validate products if provided
    if (products) {
      if (!Array.isArray(products)) {
        return res.status(400).json({ message: 'Products must be an array' });
      }
      for (const item of products) {
        const { product_id, stock_provided } = item;
        if (!product_id || stock_provided === undefined || stock_provided < 0) {
          return res.status(400).json({ message: 'Invalid product_id or stock_provided' });
        }
        const product = await Product.findById(product_id);
        if (!product) {
          return res.status(404).json({ message: `Product ${product_id} not found` });
        }
      }
    }

    // Update fields
    if (name) supplier.name = name;
    if (contact_email) supplier.contact_email = contact_email;
    if (phone) supplier.phone = phone;
    if (address) supplier.address = address;

    if (products) {
      // Adjust stock based on changes
      for (const newItem of products) {
        const oldItem = supplier.products.find(p => p.product_id.toString() === newItem.product_id);
        const stockDifference = oldItem ? newItem.stock_provided - oldItem.stock_provided : newItem.stock_provided;
        await Product.findByIdAndUpdate(newItem.product_id, {
          $inc: { stock: stockDifference }
        });
      }
      supplier.products = products;
    }

    await supplier.save();
    res.json({ message: 'Supplier updated successfully', data: supplier });
  } catch (error) {
    console.error('Supplier update error:', error.stack);
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Supplier with this email already exists' });
    }
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/suppliers/:id - Delete a supplier (admin only)
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id);
    if (!supplier) {
      return res.status(404).json({ message: 'Supplier not found' });
    }

    // Reduce product stock before deleting
    for (const item of supplier.products) {
      await Product.findByIdAndUpdate(item.product_id, {
        $inc: { stock: -item.stock_provided }
      });
    }

    await Supplier.deleteOne({ _id: req.params.id });
    res.json({ message: 'Supplier deleted successfully' });
  } catch (error) {
    console.error('Supplier delete error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;