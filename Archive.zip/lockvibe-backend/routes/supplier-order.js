const express = require('express');
const router = express.Router();
const SupplierOrder = require('../models/SupplierOrder');
const Supplier = require('../models/Supplier');
const Product = require('../models/Product');
const { auth, adminOnly } = require('../middleware/auth');

const mongoose = require('mongoose');

// POST /api/supplier-orders - Request stock from supplier (admin only)
router.post('/', auth, adminOnly, async (req, res) => {
  const { supplier_id, products } = req.body;

  if (!supplier_id || !products || !Array.isArray(products)) {
    return res.status(400).json({ message: 'Supplier ID and products array are required' });
  }

  try {
    // Validate supplier
    const supplier = await Supplier.findById(supplier_id);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });

    // Validate products
    for (const item of products) {
      const { product_id, quantity_requested } = item;
      if (!product_id || !quantity_requested || quantity_requested < 1) {
        return res.status(400).json({ message: 'Invalid product_id or quantity_requested' });
      }
      const product = await Product.findById(product_id);
      if (!product) return res.status(404).json({ message: `Product ${product_id} not found` });
    }

    const supplierOrder = await SupplierOrder.create({ supplier_id, products });
    res.status(201).json({ message: 'Supplier order requested', data: supplierOrder });
  } catch (error) {
    console.error('Supplier order creation error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/supplier-orders/:id - Get specific request (admin only)
router.get('/:id', auth, adminOnly, async (req, res) => {
  try {
    const supplierOrder = await SupplierOrder.findById(req.params.id)
      .populate('supplier_id', 'name')
      .populate('products.product_id', 'name');
    if (!supplierOrder) return res.status(404).json({ message: 'Supplier order not found' });
    res.json({ message: 'Supplier order fetched', data: supplierOrder });
  } catch (error) {
    console.error('Supplier order fetch error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/supplier-orders?supplier_id=xyz - Get all requests for a supplier (admin only)
router.get('/', auth, adminOnly, async (req, res) => {
  const { supplier_id } = req.query;

  if (!supplier_id || !mongoose.Types.ObjectId.isValid(supplier_id)) {
    return res.status(400).json({ message: 'Valid supplier_id is required' });
  }

  try {
    const supplier = await Supplier.findById(supplier_id);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });

    const supplierOrders = await SupplierOrder.find({ supplier_id })
      .populate('supplier_id', 'name')
      .populate('products.product_id', 'name')
      .sort({ created_at: -1 });

    res.json({ message: 'Supplier orders fetched', data: supplierOrders });
  } catch (error) {
    console.error('Supplier orders list error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/supplier-orders/:id - Update supplier order status (admin only)
router.patch('/:id', auth, adminOnly, async (req, res) => {
  const { status } = req.body;

  if (!status || !['pending', 'shipped', 'delivered', 'cancelled'].includes(status)) {
    return res.status(400).json({ message: 'Valid status (pending, shipped, delivered, cancelled) is required' });
  }

  try {
    const supplierOrder = await SupplierOrder.findById(req.params.id);
    if (!supplierOrder) return res.status(404).json({ message: 'Supplier order not found' });

    // If status changes to 'delivered', update product stock
    if (status === 'delivered' && supplierOrder.status !== 'delivered') {
      for (const item of supplierOrder.products) {
        await Product.findByIdAndUpdate(item.product_id, {
          $inc: { stock: item.quantity_requested }
        });
      }
    }

    supplierOrder.status = status;
    await supplierOrder.save();

    const updatedOrder = await SupplierOrder.findById(req.params.id)
      .populate('supplier_id', 'name')
      .populate('products.product_id', 'name');

    res.json({ message: 'Supplier order updated', data: updatedOrder });
  } catch (error) {
    console.error('Supplier order update error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;