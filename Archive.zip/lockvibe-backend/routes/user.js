const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { auth, adminOnly } = require('../middleware/auth');

// POST /api/users/login - User login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    console.log("Login token payload:", { id: user._id, role: user.role });
    res.json({ message: 'Login successful', data: { token } });
  } catch (error) {
    console.error('Login error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/users/register - User registration
router.post('/register', async (req, res) => {
  const { name, email, password, address } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Name, email, and password are required' });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already in use' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const stripeCustomer = await stripe.customers.create({ email, name });

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      address,
      stripe_customer_id: stripeCustomer.id,
    });

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    console.log("Register token payload:", { id: user._id, role: user.role });
    res.status(201).json({ message: 'User registered successfully', data: { token } });
  } catch (error) {
    console.error('Registration error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/users/me - Fetch current user's profile
router.get('/me', auth, async (req, res) => {
  try {
    console.log('GET /api/users/me - req.user:', req.user);
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      console.log('User not found for ID:', req.user.id);
      return res.status(404).json({ message: 'User not found' });
    }
    console.log('User fetched:', user);
    res.json({ message: 'Profile fetched successfully', data: user });
  } catch (error) {
    console.error('Fetch user error:', error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// PATCH /api/users/me - Update current user's profile
router.patch('/me', auth, async (req, res) => {
  const { name, email, notifications } = req.body;

  try {
    console.log('PATCH /api/users/me - req.user:', req.user, 'req.body:', req.body);
    const user = await User.findById(req.user.id);
    if (!user) {
      console.log('User not found for ID:', req.user.id);
      return res.status(404).json({ message: 'User not found' });
    }

    if (name) user.name = name;
    if (email) user.email = email; // Add email uniqueness check if needed
    if (typeof notifications === 'boolean') user.notifications = notifications;

    await user.save();
    console.log('User updated:', user);
    res.json({ message: 'Profile updated successfully', data: user.toObject({ getters: true }) });
  } catch (error) {
    console.error('Update user error:', error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// GET /api/users/:id - Fetch specific user by ID
router.get('/:id', auth, async (req, res) => {
  try {
    console.log('GET /api/users/:id - req.params.id:', req.params.id, 'req.user:', req.user);
    const userId = req.params.id;
    if (req.user.id !== userId && req.user.role !== 'admin') {
      console.log('Access denied: user ID mismatch or not admin');
      return res.status(403).json({ message: 'Access denied' });
    }

    const user = await User.findById(userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'Profile fetched successfully', data: user });
  } catch (error) {
    console.error('Profile fetch error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/users/:id - Update specific user by ID (admin or self)
router.patch('/:id', auth, async (req, res) => {
  const { name, address } = req.body;

  try {
    console.log('PATCH /api/users/:id - req.params.id:', req.params.id, 'req.user:', req.user);
    const userId = req.params.id;
    if (req.user.id !== userId && req.user.role !== 'admin') {
      console.log('Access denied: user ID mismatch or not admin');
      return res.status(403).json({ message: 'Access denied' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (name) user.name = name;
    if (address && typeof address === 'object') user.address = address;

    await user.save();
    res.json({ message: 'Profile updated successfully', data: user.toObject({ getters: true }) });
  } catch (error) {
    console.error('Profile update error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/users?date_range=daily or monthly - User signup report (admin only)
router.get('/', auth, adminOnly, async (req, res) => {
  const { date_range } = req.query;

  try {
    let startDate, endDate;
    if (date_range === 'daily') {
      startDate = new Date(new Date().setDate(new Date().getDate() - 1));
      endDate = new Date();
    } else if (date_range === 'monthly') {
      startDate = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
      endDate = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
    } else {
      return res.status(400).json({ message: 'Invalid date_range parameter. Use "daily" or "monthly"' });
    }

    const users = await User.aggregate([
      { $match: { created_at: { $gte: startDate, $lte: endDate }, role: 'customer' } },
      {
        $group: {
          _id: { $dateToString: { format: date_range === 'daily' ? '%Y-%m-%d' : '%Y-%m', date: '$created_at' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    res.json({
      message: 'Report fetched successfully',
      data: {
        report: date_range,
        results: users.map((u) => ({ date: u._id, signups: u.count })),
        total: users.reduce((sum, u) => sum + u.count, 0),
      },
    });
  } catch (error) {
    console.error('User report error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;