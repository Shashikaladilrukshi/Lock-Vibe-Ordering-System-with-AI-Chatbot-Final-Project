const express = require("express");
const router = express.Router();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const Order = require("../models/Order");
const Payment = require("../models/Payment");
const User = require("../models/User");
const Notification = require("../models/Notification"); // Add this
const { auth, adminOnly } = require("../middleware/auth");

router.post("/", auth, async (req, res) => {
  const { order_id, payment_method_id } = req.body;

  if (!order_id || !payment_method_id) {
    return res.status(400).json({ message: "Order ID and payment method ID are required" });
  }

  try {
    // Fetch order
    const order = await Order.findById(order_id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    if (order.customer_id.toString() !== req.user.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    if (order.payment_status !== "pending") {
      return res.status(400).json({ message: "Payment already processed" });
    }

    // Fetch user to get stripe_customer_id and notifications preference
    const user = await User.findById(req.user.id);
    if (!user || !user.stripe_customer_id) {
      return res.status(400).json({ message: "User has no Stripe customer ID" });
    }

    let finalPaymentMethodId = payment_method_id;

    // If using dummy test card, create a payment method
    if (payment_method_id === "pm_card_visa") {
      const paymentMethod = await stripe.paymentMethods.create({
        type: "card",
        card: {
          number: "4242424242424242",
          exp_month: 12,
          exp_year: 2025,
          cvc: "123",
        },
      });
      finalPaymentMethodId = paymentMethod.id;

      await stripe.paymentMethods.attach(finalPaymentMethodId, {
        customer: user.stripe_customer_id,
      });
    }

    const amountInCents = Math.round(order.total_amount * 100);

    // Create PaymentIntent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency: "usd",
      payment_method: finalPaymentMethodId,
      customer: user.stripe_customer_id,
      confirmation_method: "manual",
      confirm: true,
      return_url: "http://localhost:3000/payment-success",
    });

    // Save payment record
    const payment = await Payment.create({
      order_id,
      customer_id: req.user.id,
      amount: amountInCents,
      stripe_payment_id: paymentIntent.id,
      status: paymentIntent.status === "succeeded" ? "succeeded" : "pending",
    });

    // Update order payment status
    order.payment_status = paymentIntent.status === "succeeded" ? "paid" : "pending";
    await order.save();

    // Create notification if payment succeeded and user has notifications enabled
    if (paymentIntent.status === "succeeded" && user.notifications) {
      await Notification.create({
        user_id: req.user.id,
        message: `Payment for order ${order_id} succeeded! Total: $${order.total_amount.toFixed(2)}`,
      });
    }

    res.json({ message: "Payment processed successfully", data: payment });
  } catch (error) {
    console.error("Payment processing error:", error.stack);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// GET /api/payments/:id - Fetch payment details
router.get("/:id", auth, async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id).populate("order_id", "total_amount status");
    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }
    if (payment.customer_id.toString() !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied" });
    }

    res.json({ message: "Payment fetched successfully", data: payment });
  } catch (error) {
    console.error("Payment fetch error:", error.stack);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// PATCH /api/payments/:id - Update payment status (admin only)
router.patch("/:id", auth, adminOnly, async (req, res) => {
  const { status } = req.body;

  if (!status || !["pending", "succeeded", "failed"].includes(status)) {
    return res.status(400).json({ message: "Valid status is required (pending, succeeded, failed)" });
  }

  try {
    const payment = await Payment.findById(req.params.id);
    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }

    payment.status = status;
    await payment.save();

    // Update order payment status
    const order = await Order.findById(payment.order_id);
    if (order) {
      order.payment_status = status === "succeeded" ? "paid" : status;
      await order.save();

      // Notify user if status changes to succeeded and notifications are enabled
      const user = await User.findById(order.customer_id);
      if (status === "succeeded" && user.notifications) {
        await Notification.create({
          user_id: order.customer_id,
          message: `Payment for order ${order._id} succeeded! Total: $${order.total_amount.toFixed(2)}`,
        });
      }
    }

    res.json({ message: "Payment status updated successfully", data: payment });
  } catch (error) {
    console.error("Payment update error:", error.stack);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// POST /api/payments/webhook - Stripe webhook handler
router.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const sig = req.headers["stripe-signature"];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);

    if (event.type === "payment_intent.succeeded") {
      const paymentIntent = event.data.object;
      const payment = await Payment.findOne({ stripe_payment_id: paymentIntent.id });
      if (payment) {
        payment.status = "succeeded";
        await payment.save();

        const order = await Order.findById(payment.order_id);
        if (order) {
          order.payment_status = "paid";
          await order.save();

          const user = await User.findById(payment.customer_id);
          if (user.notifications) {
            await Notification.create({
              user_id: payment.customer_id,
              message: `Payment for order ${payment.order_id} succeeded via webhook! Total: $${(payment.amount / 100).toFixed(2)}`,
            });
          }
        }
      }
    } else if (event.type === "payment_intent.payment_failed") {
      const paymentIntent = event.data.object;
      const payment = await Payment.findOne({ stripe_payment_id: paymentIntent.id });
      if (payment) {
        payment.status = "failed";
        await payment.save();

        const order = await Order.findById(payment.order_id);
        if (order) {
          order.payment_status = "failed";
          await order.save();
        }
      }
    }

    res.json({ received: true });
  } catch (error) {
    console.error("Webhook error:", error.stack);
    res.status(400).json({ message: "Webhook error", error: error.message });
  }
});

module.exports = router;