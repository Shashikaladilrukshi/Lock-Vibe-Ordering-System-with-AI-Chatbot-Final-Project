const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Order = require('../models/Order');
const Supplier = require('../models/Supplier');
const Product = require('../models/Product');
const SupplierOrder = require('../models/SupplierOrder');
const nodemailer = require('nodemailer');
const { auth, adminOnly } = require('../middleware/auth');
const { supplierOrderEmail } = require('../utils/emailTemplates');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.example.com',
  port: process.env.EMAIL_PORT || 587,
  secure: false,
  auth: { user: process.env.EMAIL_USER || 'your-email@example.com', pass: process.env.EMAIL_PASS || 'your-password' },
});

// GET /api/admin/overview - Dashboard stats with dynamic sales
router.get('/overview', auth, adminOnly, async (req, res) => {
  try {
    const totalSalesResult = await Order.aggregate([
      { $match: { status: 'delivered' } },
      { $group: { _id: null, total: { $sum: '$total_amount' } } },
    ]).exec();
    const totalSales = totalSalesResult.length > 0 ? totalSalesResult[0].total : 0;

    const totalOrders = await Order.countDocuments().exec();
    const totalCustomers = await User.countDocuments({ role: 'customer' }).exec();
    const avgOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0;

    const recentOrders = await Order.find()
      .sort({ created_at: -1 })
      .limit(5)
      .populate({
        path: 'customer_id',
        select: 'name email',
        model: 'User',
      })
      .populate({
        path: 'products.product_id',
        select: 'name',
        model: 'Product',
      })
      .exec();

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    const salesData = await Order.aggregate([
      { $match: { status: 'delivered', created_at: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m', date: '$created_at' } },
          total: { $sum: '$total_amount' },
        },
      },
      { $sort: { _id: 1 } },
    ]).exec();

    res.json({
      message: 'Overview fetched successfully',
      data: {
        totalSales,
        totalOrders,
        totalCustomers,
        avgOrderValue: Number(avgOrderValue.toFixed(2)),
        recentOrders,
        salesData,
      },
    });
  } catch (error) {
    console.error('Overview fetch error:', {
      message: error.message,
      stack: error.stack,
      name: error.name,
    });
    res.status(500).json({ message: 'Server error fetching overview', error: error.message });
  }
});

// GET /api/admin/users - List users with signup stats
router.get('/users', auth, adminOnly, async (req, res) => {
  try {
    const users = await User.find().select('-password');
    const newUsers = await User.aggregate([
      { $match: { created_at: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } }, count: { $sum: 1 } } },
      { $sort: { _id: 1 } },
    ]);
    res.json({ message: 'Users fetched successfully', data: { users, newUsers } });
  } catch (error) {
    console.error('Fetch users error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/admin/users/:id - Edit user
router.patch('/users/:id', auth, adminOnly, async (req, res) => {
  const { name, email, role } = req.body;
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (name) user.name = name;
    if (email) user.email = email;
    if (role) user.role = role;
    await user.save();
    res.json({ message: 'User updated successfully', data: user });
  } catch (error) {
    console.error('Update user error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/admin/users/:id - Delete user
router.delete('/users/:id', auth, adminOnly, async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/admin/orders - List orders with filters
router.get('/orders', auth, adminOnly, async (req, res) => {
  const { status, date_range } = req.query;
  try {
    let query = {};
    if (status) query.status = status;
    if (date_range) {
      const now = new Date();
      query.created_at = { $gte: date_range === 'week' ? new Date(now.setDate(now.getDate() - 7)) : new Date(now.setMonth(now.getMonth() - 1)) };
    }
    const orders = await Order.find(query)
      .populate('customer_id', 'name email')
      .populate('products.product_id', 'name')
      .sort({ created_at: -1 });
    res.json({ message: 'Orders fetched successfully', data: orders });
  } catch (error) {
    console.error('Fetch orders error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/admin/orders/:id - Update order status
router.patch('/orders/:id', auth, adminOnly, async (req, res) => {
  const { status } = req.body;
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    if (status) order.status = status;
    await order.save();
    const populatedOrder = await Order.findById(req.params.id)
      .populate('customer_id', 'name email')
      .populate('products.product_id', 'name');
    res.json({ message: 'Order updated successfully', data: populatedOrder });
  } catch (error) {
    console.error('Update order error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/admin/suppliers - List suppliers
router.get('/suppliers', auth, adminOnly, async (req, res) => {
  try {
    const suppliers = await Supplier.find().populate('products.product_id', 'name');
    res.json({ message: 'Suppliers fetched successfully', data: suppliers });
  } catch (error) {
    console.error('Fetch suppliers error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/admin/suppliers - Add supplier
router.post('/suppliers', auth, adminOnly, async (req, res) => {
  const { name, contact_email, phone, address } = req.body;
  if (!name || !contact_email) return res.status(400).json({ message: 'Name and email are required' });
  try {
    const supplier = await Supplier.create({ name, contact_email, phone, address });
    res.status(201).json({ message: 'Supplier added successfully', data: supplier });
  } catch (error) {
    console.error('Add supplier error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/admin/suppliers/:id - Edit supplier
router.patch('/suppliers/:id', auth, adminOnly, async (req, res) => {
  const { name, contact_email, phone, address } = req.body;
  try {
    const supplier = await Supplier.findById(req.params.id);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });
    if (name) supplier.name = name;
    if (contact_email) supplier.contact_email = contact_email;
    if (phone) supplier.phone = phone;
    if (address) supplier.address = address;
    await supplier.save();
    res.json({ message: 'Supplier updated successfully', data: supplier });
  } catch (error) {
    console.error('Update supplier error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/admin/suppliers/:id - Delete supplier
router.delete('/suppliers/:id', auth, adminOnly, async (req, res) => {
  try {
    const supplier = await Supplier.findByIdAndDelete(req.params.id);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });
    res.json({ message: 'Supplier deleted successfully' });
  } catch (error) {
    console.error('Delete supplier error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/admin/suppliers/:id/order - Send order request
router.post('/suppliers/:id/order', auth, adminOnly, async (req, res) => {
  const { products } = req.body;
  try {
    const supplier = await Supplier.findById(req.params.id);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });

    const supplierOrder = await SupplierOrder.create({ supplier_id: supplier._id, products, status: 'pending' });
    const productDetails = await Product.find({ _id: { $in: products.map((p) => p.product_id) } });
    const mailOptions = supplierOrderEmail(supplier, products, productDetails);

    await transporter.sendMail(mailOptions);
    res.json({ message: 'Order request sent successfully', data: supplierOrder });
  } catch (error) {
    console.error('Send order email error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/admin/products - List all products
router.get('/products', auth, adminOnly, async (req, res) => {
  try {
    const products = await Product.find().populate('supplier_id', 'name contact_email');
    res.json({ message: 'Products fetched successfully', data: products });
  } catch (error) {
    console.error('Fetch products error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/admin/products - Add product
router.post('/products', auth, adminOnly, async (req, res) => {
  const { name, description, price, stock, image_url, supplier_id, category } = req.body;
  if (!name || !price || !stock) {
    return res.status(400).json({ message: 'Name, price, and stock are required' });
  }
  try {
    const product = await Product.create({ name, description, price, stock, image_url, supplier_id, category });
    res.status(201).json({ message: 'Product added successfully', data: product });
  } catch (error) {
    console.error('Add product error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH /api/admin/products/:id - Edit product
router.patch('/products/:id', auth, adminOnly, async (req, res) => {
  const { name, description, price, stock, image_url, supplier_id, category } = req.body;
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    if (name) product.name = name;
    if (description) product.description = description;
    if (price !== undefined) product.price = Number(price);
    if (stock !== undefined) product.stock = Number(stock);
    if (image_url) product.image_url = image_url;
    if (supplier_id) product.supplier_id = supplier_id;
    if (category) product.category = category;
    await product.save();
    res.json({ message: 'Product updated successfully', data: product });
  } catch (error) {
    console.error('Update product error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE /api/admin/products/:id - Delete product
router.delete('/products/:id', auth, adminOnly, async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Delete product error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/admin/orders - Create order (admin testing)
router.post('/orders', auth, adminOnly, async (req, res) => {
  const { customer_id, products, total_amount, shipping_address } = req.body;
  try {
    const order = await Order.create({ customer_id, products, total_amount, shipping_address, status: 'pending' });
    res.status(201).json({ message: 'Order created successfully', data: order });
  } catch (error) {
    console.error('Create order error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/orders - User places an order
router.post('/orders', auth, async (req, res) => {
  const { products, total_amount, shipping_address } = req.body;
  try {
    if (!products || !total_amount || !shipping_address) {
      return res.status(400).json({ message: 'Products, total_amount, and shipping_address are required' });
    }
    const order = await Order.create({
      customer_id: req.user._id,
      products,
      total_amount,
      shipping_address,
      status: 'pending',
    });
    res.status(201).json({ message: 'Order placed successfully', data: order });
  } catch (error) {
    console.error('User order error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/admin/analytics - Enhanced analytics data
router.get('/analytics', auth, adminOnly, async (req, res) => {
  try {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    const salesData = await Order.aggregate([
      { $match: { status: 'delivered', created_at: { $gte: sixMonthsAgo } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$created_at' } }, total: { $sum: '$total_amount' } } },
      { $sort: { _id: 1 } },
    ]);

    const newUsers = await User.aggregate([
      { $match: { created_at: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } }, count: { $sum: 1 } } },
      { $sort: { _id: 1 } },
    ]);

    const topProducts = await Order.aggregate([
      { $unwind: '$products' },
      { $group: { _id: '$products.product_id', totalSales: { $sum: { $multiply: ['$products.quantity', '$products.price'] } }, unitsSold: { $sum: '$products.quantity' } } },
      { $sort: { totalSales: -1 } },
      { $limit: 5 },
      { $lookup: { from: 'products', localField: '_id', foreignField: '_id', as: 'product' } },
      { $unwind: '$product' },
      { $project: { name: '$product.name', totalSales: 1, unitsSold: 1 } },
    ]);

    const orderStatus = await Order.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);

    res.json({
      message: 'Analytics fetched successfully',
      data: { salesData, newUsers, topProducts, orderStatus },
    });
  } catch (error) {
    console.error('Analytics error:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;