const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const User = require('./models/User');
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// MongoDB Connection
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Routes
const userRoutes = require('./routes/user');
const productRoutes = require('./routes/product');
const orderRoutes = require('./routes/order');
const paymentRoutes = require('./routes/payment');
const supplierRoutes = require('./routes/supplier');
const chatRoutes = require('./routes/chat');
const supplierOrderRoutes = require('./routes/supplier-order');
const notificationsRoutes = require('./routes/notifications');
const adminRoutes = require('./routes/admin'); // Add this

app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes); // Public product routes
app.use('/api/orders', orderRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/suppliers', supplierRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/supplier-orders', supplierOrderRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/admin', adminRoutes); // Admin routes

// Seed Admin User
const seedAdmin = async () => {
  try {
    const adminExists = await User.findOne({ role: 'admin' });
    if (!adminExists) {
      const hashedPassword = await bcrypt.hash('adminpassword123', 10);
      await User.create({
        name: 'Admin',
        email: 'admin@lockvibe.com',
        password: hashedPassword,
        role: 'admin',
      });
      console.log('Admin user seeded successfully');
    } else {
      console.log('Admin already exists');
    }
  } catch (error) {
    console.error('Admin seeding error:', error.stack);
  }
};

// Start Server
const PORT = process.env.PORT || 5001;
app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);
  await seedAdmin();
});