const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  stock: { type: Number, required: true },
  image_url: { type: String },
  supplier_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier' }, // Optional for now
  category: { type: String }, // e.g., "smart", "manual"
  created_at: { type: Date, default: Date.now }
});

// Indexes for fast queries
productSchema.index({ name: 1 });
productSchema.index({ supplier_id: 1 });
productSchema.index({ created_at: 1 });
productSchema.index({ category: 1 });
productSchema.index({ price: 1 });

module.exports = mongoose.model('Product', productSchema);