const mongoose = require('mongoose');

const supplierOrderSchema = new mongoose.Schema({
  supplier_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Supplier',
    required: true
  },
  products: [{
    product_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: true
    },
    quantity_requested: {
      type: Number,
      required: true,
      min: 1
    }
  }],
  status: {
    type: String,
    enum: ['pending', 'shipped', 'delivered', 'cancelled'],
    default: 'pending'
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
});

// Update timestamp on save
supplierOrderSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

// Indexes for faster queries
supplierOrderSchema.index({ supplier_id: 1 });
supplierOrderSchema.index({ created_at: 1 });

module.exports = mongoose.model('SupplierOrder', supplierOrderSchema);