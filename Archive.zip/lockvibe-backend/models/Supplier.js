const mongoose = require('mongoose');

const supplierSchema = new mongoose.Schema({
  name: { type: String, required: true },
  contact_email: { type: String, required: true, unique: true },
  phone: { type: String },
  address: {
    street: String,
    city: String,
    state: String,
    zip: String,
    country: String
  },
  products: [{
    product_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    stock_provided: { type: Number, required: true, min: 0 }
  }],
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

supplierSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

supplierSchema.index({ contact_email: 1 });
supplierSchema.index({ created_at: 1 });

module.exports = mongoose.model('Supplier', supplierSchema);