const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  order_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  customer_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true }, // In cents for Stripe
  currency: { type: String, default: 'usd' },
  status: { type: String, enum: ['pending', 'succeeded', 'failed'], default: 'pending' },
  stripe_payment_id: { type: String }, // Stripe PaymentIntent ID
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

paymentSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

paymentSchema.index({ order_id: 1 });
paymentSchema.index({ customer_id: 1 });
paymentSchema.index({ created_at: 1 });

module.exports = mongoose.model('Payment', paymentSchema);