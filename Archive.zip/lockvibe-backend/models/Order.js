const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  customer_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  products: [{
    product_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    quantity: { type: Number, required: true },
    price: { type: Number, required: true } // Price at time of order
  }],
  total_amount: { type: Number, required: true },
  status: { type: String, enum: ['pending', 'shipped', 'delivered'], default: 'pending' },
  payment_status: { type: String, enum: ['pending', 'paid', 'failed'], default: 'pending' },
  shipping_address: {
    street: String,
    city: String,
    state: String,
    zip: String,
    country: String
  },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

// Update updated_at on save
orderSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  next();
});

// Indexes for performance
orderSchema.index({ customer_id: 1 });
orderSchema.index({ created_at: 1 });
orderSchema.index({ status: 1 });

module.exports = mongoose.model('Order', orderSchema);