const supplierOrderEmail = (supplier, products, productDetails) => ({
    from: process.env.EMAIL_USER,
    to: supplier.contact_email,
    subject: 'New Supplier Order Request - LockVibe',
    text: `
  Dear ${supplier.name},
  
  We hope this message finds you well. We're reaching out to request the following items for our inventory at LockVibe:
  
  ${products
    .map((p) => {
      const prod = productDetails.find((pd) => pd._id.toString() === p.product_id.toString());
      return `- ${p.quantity_requested} x ${prod?.name || 'Unknown Product'}`;
    })
    .join('\n')}
  
  Please let us know your availability and estimated delivery timeline. Feel free to reply to this email or contact us at ${process.env.EMAIL_USER}.
  
  Thank you for your partnership!
  
  Best regards,
  The LockVibe Admin Team
    `,
    html: `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { font-family: Arial, sans-serif; color: #333; }
      .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
      h2 { color: #1a202c; }
      ul { list-style-type: none; padding: 0; }
      li { margin: 10px 0; }
      .footer { margin-top: 20px; font-size: 12px; color: #666; }
    </style>
  </head>
  <body>
    <div class="container">
      <h2>Dear ${supplier.name},</h2>
      <p>We hope this message finds you well. We're reaching out to request the following items for our inventory at LockVibe:</p>
      <ul>
        ${products
          .map((p) => {
            const prod = productDetails.find((pd) => pd._id.toString() === p.product_id.toString());
            return `<li>${p.quantity_requested} x ${prod?.name || 'Unknown Product'}</li>`;
          })
          .join('')}
      </ul>
      <p>Please let us know your availability and estimated delivery timeline. Feel free to reply to this email or contact us at ${process.env.EMAIL_USER}.</p>
      <p>Thank you for your partnership!</p>
      <p>Best regards,<br>The LockVibe Admin Team</p>
      <div class="footer">LockVibe | Automated Email</div>
    </div>
  </body>
  </html>
    `,
  });
  
  module.exports = { supplierOrderEmail };