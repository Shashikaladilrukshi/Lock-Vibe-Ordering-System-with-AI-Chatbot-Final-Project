import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: number;
}

interface UiState {
  isDarkMode: boolean;
  isChatbotOpen: boolean;
  messages: Message[];
}

const initialState: UiState = {
  isDarkMode: true,
  isChatbotOpen: false,
  messages: [],
};

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    toggleDarkMode: (state) => {
      state.isDarkMode = !state.isDarkMode;
    },
    toggleChatbot: (state) => {
      state.isChatbotOpen = !state.isChatbotOpen;
    },
    addMessage: (state, action: PayloadAction<{ text: string; sender: 'user' | 'bot' }>) => {
      state.messages.push({
        id: Date.now().toString(),
        text: action.payload.text,
        sender: action.payload.sender,
        timestamp: Date.now(),
      });
    },
  },
});

export const { toggleDarkMode, toggleChatbot, addMessage } = uiSlice.actions;
export default uiSlice.reducer;