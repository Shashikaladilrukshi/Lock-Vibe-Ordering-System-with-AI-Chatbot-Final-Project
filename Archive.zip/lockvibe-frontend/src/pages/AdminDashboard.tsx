import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '../store';
import axios from 'axios';
import toast from 'react-hot-toast';
import {
  LayoutDashboard,
  Package,
  Users,
  ShoppingBag,
  BarChart3,
  Plus,
  Truck,
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';
import { format } from 'date-fns';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend);

const OrdersPage = ({ orders, onUpdate }) => {
  const [filterStatus, setFilterStatus] = useState('');
  const filteredOrders = filterStatus ? orders.filter((o) => o.status === filterStatus) : orders;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Orders</h2>
      <div className="flex mb-4 space-x-4">
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-4 py-2 bg-gray-800 rounded-lg">
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="shipped">Shipped</option>
          <option value="delivered">Delivered</option>
        </select>
      </div>
      <div className="p-4 bg-gray-800 rounded-lg">
        <table className="w-full">
          <thead>
            <tr className="text-left border-b border-gray-700">
              <th className="pb-3">Order ID</th>
              <th className="pb-3">Customer</th>
              <th className="pb-3">Date</th>
              <th className="pb-3">Status</th>
              <th className="pb-3 text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.map((order) => (
              <tr key={order._id} className="border-b border-gray-700">
                <td className="py-3">{order._id}</td>
                <td>{order.customer_id?.name || 'Unknown'}</td>
                <td>{format(new Date(order.created_at), 'MMM dd, yyyy')}</td>
                <td>
                  <select value={order.status} onChange={(e) => onUpdate(order._id, e.target.value)} className="p-1 bg-gray-700 rounded">
                    <option value="pending">Pending</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </td>
                <td className="text-right">Rs {order.total_amount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const ProductsPage = ({ products, suppliers, onAdd, onEdit, onDelete }) => {
  const [newProduct, setNewProduct] = useState({ name: '', description: '', price: 0, stock: 0, supplier_id: '', category: '', image_url: '' });

  const handleAdd = async (e) => {
    e.preventDefault();
    await onAdd(newProduct);
    setNewProduct({ name: '', description: '', price: 0, stock: 0, supplier_id: '', category: '', image_url: '' });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Products</h2>
      <form onSubmit={handleAdd} className="p-4 space-y-4 bg-gray-800 rounded-lg">
        <input type="text" placeholder="Enter product name" value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter product description" value={newProduct.description} onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="number" placeholder="Enter price" value={newProduct.price || ''} onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="number" placeholder="Enter stock" value={newProduct.stock || ''} onChange={(e) => setNewProduct({ ...newProduct, stock: Number(e.target.value) })} className="w-full p-2 bg-gray-700 rounded" />
        <select value={newProduct.supplier_id} onChange={(e) => setNewProduct({ ...newProduct, supplier_id: e.target.value })} className="w-full p-2 bg-gray-700 rounded">
          <option value="">Select a supplier</option>
          {suppliers.map((s) => (
            <option key={s._id} value={s._id}>{s.name}</option>
          ))}
        </select>
        <input type="text" placeholder="Enter category" value={newProduct.category} onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter image URL" value={newProduct.image_url} onChange={(e) => setNewProduct({ ...newProduct, image_url: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <button type="submit" className="px-4 py-2 text-white bg-teal-500 rounded hover:bg-teal-600">Add Product</button>
      </form>
      <div className="p-4 bg-gray-800 rounded-lg">
        <table className="w-full">
          <thead>
            <tr className="text-left border-b border-gray-700">
              <th className="pb-3">Image</th>
              <th className="pb-3">Name</th>
              <th className="pb-3">Price</th>
              <th className="pb-3">Stock</th>
              <th className="pb-3">Supplier</th>
              <th className="pb-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product._id} className="border-b border-gray-700">
                <td className="py-3">
                  {product.image_url ? (
                    <img src={product.image_url} alt={product.name} className="object-cover w-10 h-10 rounded" />
                  ) : (
                    'N/A'
                  )}
                </td>
                <td>{product.name}</td>
                <td>Rs {product.price}</td>
                <td>{product.stock}</td>
                <td>{product.supplier_id?.name || 'N/A'}</td>
                <td>
                  <button onClick={() => onEdit(product._id, { stock: product.stock + 10 })} className="mr-4 text-teal-500">Add Stock</button>
                  <button onClick={() => onDelete(product._id)} className="text-red-500">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const SuppliersPage = ({ suppliers, products, onAdd, onEdit, onDelete, onOrder }) => {
  const [newSupplier, setNewSupplier] = useState({ name: '', contact_email: '', phone: '', address: { street: '', city: '', state: '', zip: '', country: '' } });
  const [orderRequest, setOrderRequest] = useState({ supplierId: '', products: [{ product_id: '', quantity_requested: 0 }] });

  const handleAddSupplier = async (e) => {
    e.preventDefault();
    await onAdd(newSupplier);
    setNewSupplier({ name: '', contact_email: '', phone: '', address: { street: '', city: '', state: '', zip: '', country: '' } });
  };

  const handleSendOrder = async (e) => {
    e.preventDefault();
    await onOrder(orderRequest.supplierId, orderRequest.products);
    setOrderRequest({ supplierId: '', products: [{ product_id: '', quantity_requested: 0 }] });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Suppliers</h2>
      <form onSubmit={handleAddSupplier} className="p-4 space-y-4 bg-gray-800 rounded-lg">
        <input type="text" placeholder="Enter supplier name" value={newSupplier.name} onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="email" placeholder="Enter contact email" value={newSupplier.contact_email} onChange={(e) => setNewSupplier({ ...newSupplier, contact_email: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter phone number" value={newSupplier.phone} onChange={(e) => setNewSupplier({ ...newSupplier, phone: e.target.value })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter street" value={newSupplier.address.street} onChange={(e) => setNewSupplier({ ...newSupplier, address: { ...newSupplier.address, street: e.target.value } })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter city" value={newSupplier.address.city} onChange={(e) => setNewSupplier({ ...newSupplier, address: { ...newSupplier.address, city: e.target.value } })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter state" value={newSupplier.address.state} onChange={(e) => setNewSupplier({ ...newSupplier, address: { ...newSupplier.address, state: e.target.value } })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter ZIP" value={newSupplier.address.zip} onChange={(e) => setNewSupplier({ ...newSupplier, address: { ...newSupplier.address, zip: e.target.value } })} className="w-full p-2 bg-gray-700 rounded" />
        <input type="text" placeholder="Enter country" value={newSupplier.address.country} onChange={(e) => setNewSupplier({ ...newSupplier, address: { ...newSupplier.address, country: e.target.value } })} className="w-full p-2 bg-gray-700 rounded" />
        <button type="submit" className="px-4 py-2 text-white bg-teal-500 rounded hover:bg-teal-600">Add Supplier</button>
      </form>
      <div className="p-4 bg-gray-800 rounded-lg">
        <table className="w-full">
          <thead>
            <tr className="text-left border-b border-gray-700">
              <th className="pb-3">Name</th>
              <th className="pb-3">Email</th>
              <th className="pb-3">Phone</th>
              <th className="pb-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {suppliers.map((supplier) => (
              <tr key={supplier._id} className="border-b border-gray-700">
                <td className="py-3">{supplier.name}</td>
                <td>{supplier.contact_email}</td>
                <td>{supplier.phone || 'N/A'}</td>
                <td>
                  <button onClick={() => setOrderRequest({ ...orderRequest, supplierId: supplier._id })} className="mr-4 text-green-500">Order</button>
                  <button onClick={() => onDelete(supplier._id)} className="text-red-500">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <form onSubmit={handleSendOrder} className="p-4 space-y-4 bg-gray-800 rounded-lg">
        <select value={orderRequest.supplierId} onChange={(e) => setOrderRequest({ ...orderRequest, supplierId: e.target.value })} className="w-full p-2 bg-gray-700 rounded">
          <option value="">Select a supplier</option>
          {suppliers.map((s) => (
            <option key={s._id} value={s._id}>{s.name}</option>
          ))}
        </select>
        {orderRequest.products.map((item, idx) => (
          <div key={idx} className="flex space-x-2">
            <select
              value={item.product_id}
              onChange={(e) => {
                const newProducts = [...orderRequest.products];
                newProducts[idx].product_id = e.target.value;
                setOrderRequest({ ...orderRequest, products: newProducts });
              }}
              className="w-full p-2 bg-gray-700 rounded"
            >
              <option value="">Select a product</option>
              {products.map((p) => (
                <option key={p._id} value={p._id}>{p.name}</option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Qty"
              value={item.quantity_requested || ''}
              onChange={(e) => {
                const newProducts = [...orderRequest.products];
                newProducts[idx].quantity_requested = Number(e.target.value);
                setOrderRequest({ ...orderRequest, products: newProducts });
              }}
              className="w-20 p-2 bg-gray-700 rounded"
            />
          </div>
        ))}
        <button type="button" onClick={() => setOrderRequest({ ...orderRequest, products: [...orderRequest.products, { product_id: '', quantity_requested: 0 }] })} className="text-teal-500">
          + Add Item
        </button>
        <button type="submit" className="px-4 py-2 text-white bg-green-500 rounded hover:bg-green-600">Send Order Request</button>
      </form>
    </div>
  );
};

const CustomersPage = ({ users, onEdit, onDelete }) => {
  const [editCustomer, setEditCustomer] = useState(null);

  const customers = users.filter((u) => u.role === 'customer');

  const handleEditSubmit = async (e) => {
    e.preventFormDataEvent();
    await onEdit(editCustomer._id, { name: editCustomer.name, email: editCustomer.email });
    setEditCustomer(null);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Customers</h2>
      <div className="p-4 bg-gray-800 rounded-lg">
        <table className="w-full">
          <thead>
            <tr className="text-left border-b border-gray-700">
              <th className="pb-3">Name</th>
              <th className="pb-3">Email</th>
              <th className="pb-3">Signup Date</th>
              <th className="pb-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((customer) => (
              <tr key={customer._id} className="border-b border-gray-700">
                <td className="py-3">{customer.name}</td>
                <td>{customer.email}</td>
                <td>{format(new Date(customer.created_at), 'MMM dd, yyyy')}</td>
                <td>
                  <button onClick={() => setEditCustomer(customer)} className="mr-4 text-teal-500">Edit</button>
                  <button onClick={() => onDelete(customer._id)} className="text-red-500">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editCustomer && (
        <form onSubmit={handleEditSubmit} className="p-4 space-y-4 bg-gray-800 rounded-lg">
          <input
            type="text"
            placeholder="Enter customer name"
            value={editCustomer.name}
            onChange={(e) => setEditCustomer({ ...editCustomer, name: e.target.value })}
            className="w-full p-2 bg-gray-700 rounded"
          />
          <input
            type="email"
            placeholder="Enter customer email"
            value={editCustomer.email}
            onChange={(e) => setEditCustomer({ ...editCustomer, email: e.target.value })}
            className="w-full p-2 bg-gray-700 rounded"
          />
          <div className="flex space-x-4">
            <button type="submit" className="px-4 py-2 text-white bg-teal-500 rounded hover:bg-teal-600">Save</button>
            <button type="button" onClick={() => setEditCustomer(null)} className="px-4 py-2 text-white bg-gray-600 rounded hover:bg-gray-700">Cancel</button>
          </div>
        </form>
      )}
    </div>
  );
};

const AnalyticsPage = ({ analytics }) => {
  const salesData = {
    labels: analytics.salesData.map((d) => format(new Date(d._id), 'MMM yyyy')),
    datasets: [{ label: 'Sales', data: analytics.salesData.map((d) => d.total), borderColor: 'rgb(20, 184, 166)', backgroundColor: 'rgba(20, 184, 166, 0.1)', tension: 0.4 }],
  };

  const userRegistrations = {
    labels: analytics.newUsers.map((u) => format(new Date(u._id), 'EEE')),
    datasets: [{ label: 'New Users', data: analytics.newUsers.map((u) => u.count), backgroundColor: 'rgb(147, 51, 234)' }],
  };

  const topProducts = {
    labels: analytics.topProducts.map((p) => p.name),
    datasets: [{ label: 'Total Sales', data: analytics.topProducts.map((p) => p.totalSales), backgroundColor: 'rgb(34, 197, 94)' }],
  };

  const orderStatus = {
    labels: analytics.orderStatus.map((s) => s._id),
    datasets: [{ data: analytics.orderStatus.map((s) => s.count), backgroundColor: ['rgb(249, 115, 22)', 'rgb(59, 130, 246)', 'rgb(34, 197, 94)'], hoverOffset: 4 }],
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Analytics</h2>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="p-6 bg-gray-800 rounded-lg">
          <h3 className="mb-4 text-xl font-semibold">Sales Overview (Last 6 Months)</h3>
          <Line data={salesData} options={{ responsive: true, scales: { y: { beginAtZero: true } } }} />
        </div>
        <div className="p-6 bg-gray-800 rounded-lg">
          <h3 className="mb-4 text-xl font-semibold">New Users (Last 7 Days)</h3>
          <Bar data={userRegistrations} options={{ responsive: true, scales: { y: { beginAtZero: true } } }} />
        </div>
        <div className="p-6 bg-gray-800 rounded-lg">
          <h3 className="mb-4 text-xl font-semibold">Top 5 Products</h3>
          <Bar data={topProducts} options={{ responsive: true, scales: { y: { beginAtZero: true } } }} />
        </div>
        <div className="p-6 bg-gray-800 rounded-lg">
          <h3 className="mb-4 text-xl font-semibold">Order Status</h3>
          <Pie data={orderStatus} options={{ responsive: true }} />
        </div>
      </div>
    </div>
  );
};

const AdminDashboard = () => {
  const location = useLocation();
  const auth = useSelector((state: RootState) => state.auth);
  const [overview, setOverview] = useState({ totalSales: 0, totalOrders: 0, totalCustomers: 0, avgOrderValue: 0, recentOrders: [], salesData: [] });
  const [analytics, setAnalytics] = useState({ salesData: [], newUsers: [], topProducts: [], orderStatus: [] });
  const [orders, setOrders] = useState([]);
  const [users, setUsers] = useState({ users: [], newUsers: [] });
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);

  useEffect(() => {
    if (!auth.isAuthenticated || auth.user?.role !== 'admin') {
      toast.error('Admins only, fam!');
      return;
    }

    const fetchData = async () => {
      try {
        const overviewResponse = await axios.get('http://localhost:5001/api/admin/overview', { headers: { Authorization: `Bearer ${auth.user.token}` } });
        setOverview(overviewResponse.data.data);

        const analyticsResponse = await axios.get('http://localhost:5001/api/admin/analytics', { headers: { Authorization: `Bearer ${auth.user.token}` } });
        setAnalytics(analyticsResponse.data.data);

        const ordersResponse = await axios.get('http://localhost:5001/api/admin/orders', { headers: { Authorization: `Bearer ${auth.user.token}` } });
        setOrders(ordersResponse.data.data);

        const usersResponse = await axios.get('http://localhost:5001/api/admin/users', { headers: { Authorization: `Bearer ${auth.user.token}` } });
        setUsers(usersResponse.data.data);

        const productsResponse = await axios.get('http://localhost:5001/api/admin/products', { headers: { Authorization: `Bearer ${auth.user.token}` } });
        setProducts(productsResponse.data.data);

        const suppliersResponse = await axios.get('http://localhost:5001/api/admin/suppliers', { headers: { Authorization: `Bearer ${auth.user.token}` } });
        setSuppliers(suppliersResponse.data.data);
      } catch (err) {
        toast.error('Failed to load dashboard: ' + (err.response?.data?.message || err.message));
        console.error('Fetch error:', err.response?.data || err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [auth]);

  const handleUpdateOrder = async (id, status) => {
    try {
      const response = await axios.patch(`http://localhost:5001/api/admin/orders/${id}`, { status }, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setOrders(orders.map((o) => (o._id === id ? response.data.data : o)));
      setOverview({ ...overview, recentOrders: overview.recentOrders.map((o) => (o._id === id ? response.data.data : o)) });
      toast.success('Order updated!');
    } catch (err) {
      toast.error('Failed to update order: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleAddProduct = async (data) => {
    try {
      const response = await axios.post('http://localhost:5001/api/admin/products', data, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setProducts([...products, response.data.data]);
      toast.success('Product added!');
    } catch (err) {
      toast.error('Failed to add product: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleEditProduct = async (id, data) => {
    try {
      const response = await axios.patch(`http://localhost:5001/api/admin/products/${id}`, data, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setProducts(products.map((p) => (p._id === id ? response.data.data : p)));
      toast.success('Product updated!');
    } catch (err) {
      toast.error('Failed to update product: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      await axios.delete(`http://localhost:5001/api/admin/products/${id}`, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setProducts(products.filter((p) => p._id !== id));
      toast.success('Product deleted!');
    } catch (err) {
      toast.error('Failed to delete product: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleAddSupplier = async (data) => {
    try {
      const response = await axios.post('http://localhost:5001/api/admin/suppliers', data, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setSuppliers([...suppliers, response.data.data]);
      toast.success('Supplier added!');
    } catch (err) {
      toast.error('Failed to add supplier: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleEditSupplier = async (id, data) => {
    try {
      const response = await axios.patch(`http://localhost:5001/api/admin/suppliers/${id}`, data, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setSuppliers(suppliers.map((s) => (s._id === id ? response.data.data : s)));
      toast.success('Supplier updated!');
    } catch (err) {
      toast.error('Failed to update supplier: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleDeleteSupplier = async (id) => {
    try {
      await axios.delete(`http://localhost:5001/api/admin/suppliers/${id}`, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setSuppliers(suppliers.filter((s) => s._id !== id));
      toast.success('Supplier deleted!');
    } catch (err) {
      toast.error('Failed to delete supplier: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleSendOrder = async (supplierId, products) => {
    try {
      await axios.post(`http://localhost:5001/api/admin/suppliers/${supplierId}/order`, { products }, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      toast.success('Order request sent!');
    } catch (err) {
      toast.error('Failed to send order: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleEditUser = async (id, data) => {
    try {
      const response = await axios.patch(`http://localhost:5001/api/admin/users/${id}`, data, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setUsers({ ...users, users: users.users.map((u) => (u._id === id ? response.data.data : u)) });
      toast.success('User updated!');
    } catch (err) {
      toast.error('Failed to update user: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleDeleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:5001/api/admin/users/${id}`, { headers: { Authorization: `Bearer ${auth.user.token}` } });
      setUsers({ ...users, users: users.users.filter((u) => u._id !== id) });
      toast.success('User deleted!');
    } catch (err) {
      toast.error('Failed to delete user: ' + (err.response?.data?.message || err.message));
    }
  };

  if (loading) return <div className="min-h-[calc(100vh-4rem)] bg-gray-900 text-gray-400">Loading...</div>;
  if (auth.user?.role !== 'admin') return <div className="min-h-[calc(100vh-4rem)] bg-gray-900 text-gray-400">Access denied.</div>;

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
        <div className="p-6 bg-gray-800 rounded-lg">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Total Sales</h3>
            <ShoppingBag className="w-6 h-6 text-teal-500" />
          </div>
          <p className="mt-2 text-3xl font-bold">Rs {overview.totalSales}</p>
          <p className="mt-2 text-sm text-green-500">+12% from last month</p>
        </div>
        <div className="p-6 bg-gray-800 rounded-lg">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Orders</h3>
            <Package className="w-6 h-6 text-purple-500" />
          </div>
          <p className="mt-2 text-3xl font-bold">{overview.totalOrders}</p>
          <p className="mt-2 text-sm text-green-500">+8% from last month</p>
        </div>
        <div className="p-6 bg-gray-800 rounded-lg">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Customers</h3>
            <Users className="w-6 h-6 text-blue-500" />
          </div>
          <p className="mt-2 text-3xl font-bold">{overview.totalCustomers}</p>
          <p className="mt-2 text-sm text-green-500">+15% from last month</p>
        </div>
        <div className="p-6 bg-gray-800 rounded-lg">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Avg. Order Value</h3>
            <BarChart3 className="w-6 h-6 text-orange-500" />
          </div>
          <p className="mt-2 text-3xl font-bold">Rs {overview.avgOrderValue}</p>
          <p className="mt-2 text-sm text-red-500">-3% from last month</p>
        </div>
      </div>
      <div className="p-6 bg-gray-800 rounded-lg">
        <h3 className="mb-4 text-xl font-semibold">Recent Orders</h3>
        <table className="w-full">
          <thead>
            <tr className="text-left border-b border-gray-700">
              <th className="pb-3">Order ID</th>
              <th className="pb-3">Customer</th>
              <th className="pb-3">Date</th>
              <th className="pb-3">Status</th>
              <th className="pb-3 text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {overview.recentOrders.map((order) => (
              <tr
                key={order._id}
                className="border-b border-gray-700 cursor-pointer hover:bg-gray-700"
                onClick={() => setSelectedOrder(order)}
              >
                <td className="py-3">{order._id}</td>
                <td>{order.customer_id?.name || 'Unknown'}</td>
                <td>{format(new Date(order.created_at), 'MMM dd, yyyy')}</td>
                <td>
                  <span className={`px-2 py-1 rounded-full text-xs ${order.status === 'delivered' ? 'bg-green-500/20 text-green-400' : order.status === 'shipped' ? 'bg-blue-500/20 text-blue-400' : 'bg-orange-500/20 text-orange-400'}`}>
                    {order.status}
                  </span>
                </td>
                <td className="text-right">Rs {order.total_amount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setSelectedOrder(null)}>
          <div className="p-6 bg-gray-800 rounded-lg w-full max-w-2xl max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-4 text-2xl font-bold">Order #{selectedOrder._id}</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold">Customer</h3>
                <p>{selectedOrder.customer_id?.name || 'Unknown'} ({selectedOrder.customer_id?.email || 'N/A'})</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold">Shipping Address</h3>
                <p>
                  {selectedOrder.shipping_address.street}, {selectedOrder.shipping_address.city}, {selectedOrder.shipping_address.state} {selectedOrder.shipping_address.zip}, {selectedOrder.shipping_address.country}
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold">Order Details</h3>
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b border-gray-700">
                      <th className="pb-2">Product</th>
                      <th className="pb-2">Quantity</th>
                      <th className="pb-2 text-right">Price</th>
                      <th className="pb-2 text-right">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedOrder.products.map((item, idx) => (
                      <tr key={idx} className="border-b border-gray-700">
                        <td className="py-2">{item.product_id?.name || 'Unknown'}</td>
                        <td>{item.quantity}</td>
                        <td className="text-right">Rs {item.price}</td>
                        <td className="text-right">Rs {(item.quantity * item.price).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex justify-between">
                <p className="text-lg font-semibold">Total</p>
                <p className="text-lg font-bold">Rs {selectedOrder.total_amount}</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedOrder(null)}
              className="px-4 py-2 mt-4 text-white bg-teal-500 rounded hover:bg-teal-600"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-900">
      <div className="px-4 py-8 mx-auto max-w-7xl">
        <div className="flex flex-col gap-8 md:flex-row">
          <div className="w-full space-y-2 md:w-64">
            <Link to="/admin" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === '/admin' ? 'bg-gray-800 text-white' : 'hover:bg-gray-800/50'}`}>
              <LayoutDashboard className="w-5 h-5" />
              <span>Dashboard</span>
            </Link>
            <Link to="/admin/orders" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === '/admin/orders' ? 'bg-gray-800 text-white' : 'hover:bg-gray-800/50'}`}>
              <Package className="w-5 h-5" />
              <span>Orders</span>
            </Link>
            <Link to="/admin/products" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === '/admin/products' ? 'bg-gray-800 text-white' : 'hover:bg-gray-800/50'}`}>
              <ShoppingBag className="w-5 h-5" />
              <span>Products</span>
            </Link>
            <Link to="/admin/customers" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === '/admin/customers' ? 'bg-gray-800 text-white' : 'hover:bg-gray-800/50'}`}>
              <Users className="w-5 h-5" />
              <span>Customers</span>
            </Link>
            <Link to="/admin/suppliers" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === '/admin/suppliers' ? 'bg-gray-800 text-white' : 'hover:bg-gray-800/50'}`}>
              <Truck className="w-5 h-5" />
              <span>Suppliers</span>
            </Link>
            <Link to="/admin/analytics" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${location.pathname === '/admin/analytics' ? 'bg-gray-800 text-white' : 'hover:bg-gray-800/50'}`}>
              <BarChart3 className="w-5 h-5" />
              <span>Analytics</span>
            </Link>
          </div>
          <div className="flex-1">
            <div className="flex flex-col justify-between gap-4 mb-8 md:flex-row md:items-center">
              <div>
                <h1 className="text-2xl font-bold">Admin Dashboard</h1>
                <p className="text-gray-400">Monitor and manage your store</p>
              </div>
              <div className="flex items-center space-x-4">
                <Link to="/admin/products" className="flex items-center px-4 py-2 space-x-2 transition-colors bg-teal-500 rounded-lg hover:bg-teal-600">
                  <Plus className="w-5 h-5" />
                  <span>Add Product</span>
                </Link>
              </div>
            </div>
            <Routes>
              <Route path="/" element={renderOverview()} />
              <Route path="/orders" element={<OrdersPage orders={orders} onUpdate={handleUpdateOrder} />} />
              <Route path="/products" element={<ProductsPage products={products} suppliers={suppliers} onAdd={handleAddProduct} onEdit={handleEditProduct} onDelete={handleDeleteProduct} />} />
              <Route path="/customers" element={<CustomersPage users={users.users} onEdit={handleEditUser} onDelete={handleDeleteUser} />} />
              <Route path="/suppliers" element={<SuppliersPage suppliers={suppliers} products={products} onAdd={handleAddSupplier} onEdit={handleEditSupplier} onDelete={handleDeleteSupplier} onOrder={handleSendOrder} />} />
              <Route path="/analytics" element={<AnalyticsPage analytics={analytics} />} />
            </Routes>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;