import React, { useState, useEffect } from "react";
import { Routes, Route, Link, useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Package,
  Clock,
  CreditCard,
  User,
  Settings,
  Bell,
  Search,
  Filter,
} from "lucide-react";
import { useSelector } from "react-redux";
import { RootState } from "../store";
import axios from "axios";
import toast from "react-hot-toast";

const OrdersPage = ({ orders }: { orders: any[] }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  const filteredOrders = orders
    .filter((order) =>
      order._id.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter((order) => (filterStatus ? order.status === filterStatus : true));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Orders</h2>
        <div className="flex space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search orders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="py-2 pl-10 pr-4 bg-gray-800 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-gray-800 rounded-lg hover:bg-gray-700"
          >
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
          </select>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg">
        <div className="grid grid-cols-4 gap-4 p-4 font-medium border-b border-gray-700">
          <div>Order ID</div>
          <div>Items</div>
          <div>Status</div>
          <div>Total</div>
        </div>
        {filteredOrders.length === 0 ? (
          <p className="p-4 text-gray-400">No orders match your search.</p>
        ) : (
          filteredOrders.map((order) => (
            <div
              key={order._id}
              className="grid grid-cols-4 gap-4 p-4 border-b border-gray-700 cursor-pointer hover:bg-gray-700"
              onClick={() => navigate(`/dashboard/orders/${order._id}`)}
            >
              <div>{order._id}</div>
              <div>
                {order.products.map((p: any) => p.product_id.name).join(", ")}
              </div>
              <div>
                <span
                  className={`px-2 py-1 rounded-full text-xs ${
                    order.status === "delivered"
                      ? "bg-green-500/20 text-green-400"
                      : order.status === "pending"
                      ? "bg-orange-500/20 text-orange-400"
                      : "bg-blue-500/20 text-blue-400"
                  }`}
                >
                  {order.status}
                </span>
              </div>
              <div>Rs {order.total_amount.toFixed(2)}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const OrderDetailsPage = () => {
  const id = useLocation().pathname.split("/").pop();
  const auth = useSelector((state: RootState) => state.auth);
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const response = await axios.get(`http://localhost:5001/api/orders/${id}`, {
          headers: { Authorization: `Bearer ${auth.user?.token}` },
        });
        setOrder(response.data.data);
        console.log('Raw order data:', response.data.data);
        console.log('Created at:', response.data.data.created_at);
      } catch (err: any) {
        toast.error("Failed to fetch order details: " + (err.response?.data?.message || err.message));
        console.error("Order fetch error:", err.response?.data || err);
      } finally {
        setLoading(false);
      }
    };
    fetchOrder();
  }, [id, auth]);

  if (loading) return <p className="text-gray-400">Loading...</p>;
  if (!order) return <p className="text-gray-400">Order not found.</p>;

  // Create a date object from created_at and format it
  const orderDate = new Date(order.created_at);
  const formattedDate = isNaN(orderDate.getTime()) 
    ? "Date unavailable" 
    : orderDate.toLocaleString();

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Order Details - {order._id}</h2>
      <div className="p-6 bg-gray-800 rounded-lg">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="font-semibold">Status:</p>
            <span
              className={`px-2 py-1 rounded-full text-xs ${
                order.status === "delivered"
                  ? "bg-green-500/20 text-green-400"
                  : order.status === "pending"
                  ? "bg-orange-500/20 text-orange-400"
                  : "bg-blue-500/20 text-blue-400"
              }`}
            >
              {order.status}
            </span>
          </div>
          <div>
            <p className="font-semibold">Total:</p>
            <p>Rs {order.total_amount.toFixed(2)}</p>
          </div>
          <div>
            <p className="font-semibold">Order Date:</p>
            <p>{formattedDate}</p>
          </div>
          <div>
            <p className="font-semibold">Payment Status:</p>
            <p>{order.payment_status}</p>
          </div>
        </div>
        <div className="mt-4">
          <p className="font-semibold">Items:</p>
          <ul className="list-disc list-inside">
            {order.products.map((p: any) => (
              <li key={p.product_id._id}>
                {p.product_id.name} (x{p.quantity}) - Rs {(p.product_id.price * p.quantity).toFixed(2)}
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-4">
          <p className="font-semibold">Shipping Address:</p>
          <p>{Object.values(order.shipping_address).join(", ")}</p>
        </div>
      </div>
    </div>
  );
};

const SettingsPage = ({ user, updateUser }: { user: any; updateUser: (data: any) => void }) => {
  const [formData, setFormData] = useState({
    name: user.name || "",
    email: user.email || "",
    notifications: user.notifications || false,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateUser(formData);
      toast.success("Settings updated successfully!");
    } catch (err: any) {
      toast.error(err.response?.data?.message || "Failed to update settings");
      console.error("Update error:", err.response?.data || err);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Settings</h2>
      <form onSubmit={handleSubmit} className="p-6 space-y-6 bg-gray-800 rounded-lg">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Profile Information</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2 text-sm font-medium">Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 bg-gray-700 rounded-lg"
              />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-2 bg-gray-700 rounded-lg"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Preferences</h3>
          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={formData.notifications}
              onChange={(e) => setFormData({ ...formData, notifications: e.target.checked })}
              className="w-5 h-5 form-checkbox"
            />
            <span>Enable notifications</span>
          </label>
        </div>

        <button
          type="submit"
          className="px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600"
        >
          Save Changes
        </button>
      </form>
    </div>
  );
};

const renderOverview = ({ orders, totalOrders, pendingOrders, totalSpent }: any) => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
      <div className="p-6 bg-gray-800 rounded-lg">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Total Orders</h3>
          <Package className="w-6 h-6 text-teal-500" />
        </div>
        <p className="mt-2 text-3xl font-bold">{totalOrders}</p>
      </div>
      <div className="p-6 bg-gray-800 rounded-lg">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Pending Orders</h3>
          <Clock className="w-6 h-6 text-orange-500" />
        </div>
        <p className="mt-2 text-3xl font-bold">{pendingOrders}</p>
      </div>
      <div className="p-6 bg-gray-800 rounded-lg">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Total Spent</h3>
          <CreditCard className="w-6 h-6 text-purple-500" />
        </div>
        <p className="mt-2 text-3xl font-bold">Rs {totalSpent.toFixed(2)}</p>
      </div>
    </div>

    <div className="p-6 bg-gray-800 rounded-lg">
      <h3 className="mb-4 text-xl font-semibold">Recent Orders</h3>
      <div className="space-y-4">
        {orders.slice(0, 3).map((order: any) => (
          <div
            key={order._id}
            className="flex items-center justify-between p-4 bg-gray-700 rounded-lg"
          >
            <div>
              <div className="flex items-center space-x-4">
                <span className="text-sm font-medium">{order._id}</span>
                <span
                  className={`px-2 py-1 rounded-full text-xs ${
                    order.status === "delivered"
                      ? "bg-green-500/20 text-green-400"
                      : order.status === "pending"
                      ? "bg-orange-500/20 text-orange-400"
                      : "bg-blue-500/20 text-blue-400"
                  }`}
                >
                  {order.status}
                </span>
              </div>
              <p className="mt-1 text-sm text-gray-400">
                {order.products.map((p: any) => p.product_id.name).join(", ")}
              </p>
            </div>
            <div className="text-right">
              <p className="font-semibold">Rs {order.total_amount.toFixed(2)}</p>
              <p className="text-sm text-gray-400">
                {new Date(order.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const UserDashboard = () => {
  const location = useLocation();
  const auth = useSelector((state: RootState) => state.auth);
  const [orders, setOrders] = useState([]);
  const [user, setUser] = useState({ name: "", email: "", notifications: false });
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.isAuthenticated || !auth.user?.token) {
      toast.error("Please log in to view your dashboard - Token missing");
      console.log("Auth state:", auth);
      return;
    }

    console.log("Using token:", auth.user.token);

    const fetchData = async () => {
      try {
        const ordersResponse = await axios.get("http://localhost:5001/api/orders", {
          headers: { Authorization: `Bearer ${auth.user.token}` },
        });
        console.log("Orders response:", ordersResponse.data);
        setOrders(ordersResponse.data.data || []);

        const userResponse = await axios.get("http://localhost:5001/api/users/me", {
          headers: { Authorization: `Bearer ${auth.user.token}` },
        });
        console.log("User response:", userResponse.data);
        setUser(userResponse.data.data || { name: "", email: "", notifications: false });

        const notificationsResponse = await axios.get("http://localhost:5001/api/notifications", {
          headers: { Authorization: `Bearer ${auth.user.token}` },
        });
        console.log("Notifications response:", notificationsResponse.data);
        setNotifications(notificationsResponse.data.data || []);
      } catch (err: any) {
        const errorMessage = err.response?.data?.message || err.message || "Unknown error";
        toast.error(`Failed to load dashboard data: ${errorMessage}`);
        console.error("Fetch error:", err.response?.data || err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [auth]);

  const updateUser = async (data: any) => {
    try {
      const response = await axios.patch(
        "http://localhost:5001/api/users/me",
        data,
        { headers: { Authorization: `Bearer ${auth.user.token}` } }
      );
      console.log("Update response:", response.data);
      setUser(response.data.data);
    } catch (err: any) {
      console.error("Update request error:", err.response?.data || err);
      throw err;
    }
  };

  const markNotificationsRead = async () => {
    try {
      await axios.patch(
        "http://localhost:5001/api/notifications/read",
        {},
        { headers: { Authorization: `Bearer ${auth.user.token}` } }
      );
      setNotifications([]);
      toast.success("Notifications marked as read");
    } catch (err: any) {
      toast.error("Failed to mark notifications as read: " + (err.response?.data?.message || err.message));
      console.error("Mark notifications error:", err.response?.data || err);
    }
  };

  if (!auth.isAuthenticated) {
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gray-900">
        <p className="text-gray-400">
          Please <Link to="/login" className="text-teal-500">log in</Link> to view your dashboard.
        </p>
      </div>
    );
  }

  if (loading) {
    return <div className="min-h-[calc(100vh-4rem)] bg-gray-900 text-gray-400">Loading...</div>;
  }

  const totalOrders = orders.length;
  const pendingOrders = orders.filter((o: any) => o.status === "pending").length;
  const totalSpent = orders.reduce((sum: number, o: any) => sum + o.total_amount, 0);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-900">
      <div className="px-4 py-8 mx-auto max-w-7xl">
        <div className="flex flex-col gap-8 md:flex-row">
          <div className="w-full space-y-2 md:w-64">
            <Link
              to="/dashboard"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                location.pathname === "/dashboard"
                  ? "bg-gray-800 text-white"
                  : "hover:bg-gray-800/50"
              }`}
            >
              <User className="w-5 h-5" />
              <span>Overview</span>
            </Link>
            <Link
              to="/dashboard/orders"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                location.pathname === "/dashboard/orders"
                  ? "bg-gray-800 text-white"
                  : "hover:bg-gray-800/50"
              }`}
            >
              <Package className="w-5 h-5" />
              <span>Orders</span>
            </Link>
            <Link
              to="/dashboard/settings"
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                location.pathname === "/dashboard/settings"
                  ? "bg-gray-800 text-white"
                  : "hover:bg-gray-800/50"
              }`}
            >
              <Settings className="w-5 h-5" />
              <span>Settings</span>
            </Link>
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-2xl font-bold">Welcome back, {user.name || "User"}!</h1>
                <p className="text-gray-400">
                  Manage your orders and account settings
                </p>
              </div>
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 transition-colors bg-gray-800 rounded-lg hover:bg-gray-700"
                >
                  <Bell className="w-5 h-5" />
                  {notifications.length > 0 && (
                    <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                  )}
                </button>
                {showNotifications && (
                  <div className="absolute right-0 w-64 p-4 mt-2 bg-gray-800 rounded-lg shadow-lg">
                    <h3 className="mb-2 text-sm font-semibold">Notifications</h3>
                    {notifications.length === 0 ? (
                      <p className="text-sm text-gray-400">No new notifications</p>
                    ) : (
                      notifications.map((n: any) => (
                        <p key={n._id} className="mb-2 text-sm text-gray-300">
                          {n.message}
                        </p>
                      ))
                    )}
                    {notifications.length > 0 && (
                      <button
                        onClick={markNotificationsRead}
                        className="text-xs text-teal-500 hover:underline"
                      >
                        Mark all as read
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            <Routes>
              <Route
                path="/"
                element={renderOverview({ orders, totalOrders, pendingOrders, totalSpent })}
              />
              <Route path="/orders" element={<OrdersPage orders={orders} />} />
              <Route path="/orders/:id" element={<OrderDetailsPage />} />
              <Route path="/settings" element={<SettingsPage user={user} updateUser={updateUser} />} />
            </Routes>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;