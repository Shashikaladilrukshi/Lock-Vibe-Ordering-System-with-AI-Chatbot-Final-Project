import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const CartPage = () => {
  const { cart, removeFromCart, updateQuantity } = useCart();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-900 py-8">
      <div className="px-4 mx-auto max-w-7xl">
        <h1 className="mb-6 text-2xl font-bold">Your Cart</h1>
        {cart.length === 0 ? (
          <p className="text-gray-400">Your cart is empty. <Link to="/catalog" className="text-teal-500">Shop now!</Link></p>
        ) : (
          <>
            <div className="space-y-4">
              {cart.map((item) => (
                <motion.div
                  key={item._id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center p-4 bg-gray-800 rounded-lg"
                >
                  <img src={item.image_url || 'https://placehold.co/100x100'} alt={item.name} className="object-cover w-20 h-20 mr-4 rounded" />
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.name}</h3>
                    <p className="text-teal-400">Rs {item.price.toFixed(2)}</p>
                    <div className="flex items-center mt-2">
                      <button
                        onClick={() => updateQuantity(item._id, item.quantity - 1)}
                        className="px-2 py-1 bg-gray-700 rounded-l"
                      >
                        -
                      </button>
                      <span className="px-4 py-1 bg-gray-700">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item._id, item.quantity + 1)}
                        className="px-2 py-1 bg-gray-700 rounded-r"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <button onClick={() => removeFromCart(item._id)} className="p-2 rounded-full hover:bg-gray-700">
                    <X className="w-5 h-5" />
                  </button>
                </motion.div>
              ))}
            </div>
            <div className="p-4 mt-6 bg-gray-800 rounded-lg">
              <p className="text-xl font-bold">Total: Rs {total.toFixed(2)}</p>
              <Link
                to="/checkout"
                className="block w-full py-2 mt-4 font-semibold text-center transition-colors bg-teal-500 rounded-full hover:bg-teal-600"
              >
                Proceed to Checkout
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CartPage;