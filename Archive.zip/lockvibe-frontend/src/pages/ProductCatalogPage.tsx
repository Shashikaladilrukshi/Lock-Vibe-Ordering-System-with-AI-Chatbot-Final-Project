import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Search, ChevronDown, Filter, X, Plus } from "lucide-react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

interface Product {
  _id: string;
  name: string;
  price: number;
  image_url?: string;
  stock: number;
  category?: string;
  created_at: string;
}

const ProductCatalogPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filters, setFilters] = useState({
    category: "",
    price_min: "",
    price_max: "",
    inStock: false,
    new: false,
  });
  const [sort, setSort] = useState("newest");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [quickView, setQuickView] = useState<Product | null>(null);
  const { addToCart } = useCart(); // Hook into cart context

  const fetchProducts = useCallback(async () => {
    if (loading) return;
    setLoading(true);
    try {
      const queryParams: Record<string, string> = {
        page: page.toString(),
        limit: "12",
      };
      if (filters.category) queryParams.category = filters.category;
      if (filters.price_min) queryParams.price_min = filters.price_min;
      if (filters.price_max) queryParams.price_max = filters.price_max;
      if (filters.inStock) queryParams.inStock = "true";
      if (filters.new) queryParams.new = "true";
      if (sort) queryParams.sort = sort;

      const query = new URLSearchParams(queryParams).toString();
      console.log("Fetching with query:", query);

      const response = await axios.get(
        `http://localhost:5001/api/products?${query}`
      );
      const newProducts = response.data.data || [];
      console.log("Fetched products:", newProducts);
      setProducts((prev) =>
        page === 1 ? newProducts : [...prev, ...newProducts]
      );
      setHasMore(newProducts.length === 12);
    } catch (error) {
      console.error("Products fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [filters, page, sort]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const throttle = (func: Function, delay: number) => {
    let timeout: NodeJS.Timeout | null = null;
    return (...args: any[]) => {
      if (!timeout) {
        timeout = setTimeout(() => {
          func(...args);
          timeout = null;
        }, delay);
      }
    };
  };

  useEffect(() => {
    const handleScroll = throttle(() => {
      if (
        window.innerHeight + document.documentElement.scrollTop >=
          document.documentElement.offsetHeight - 100 &&
        hasMore &&
        !loading
      ) {
        console.log("Scroll triggered, page:", page + 1);
        setPage((prev) => prev + 1);
      }
    }, 1000);

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [hasMore, loading]);

  const handleQuickView = async (id: string) => {
    try {
      const response = await axios.get(
        `http://localhost:5001/api/products/${id}`
      );
      console.log("Quick view product:", response.data.data);
      setQuickView(response.data.data);
    } catch (error) {
      console.error("Quick view error:", error);
    }
  };

  const updateFilter = useCallback((key: string, value: string | boolean) => {
    setFilters((prev) => {
      const newFilters = { ...prev, [key]: value };
      setPage(1);
      setProducts([]); // Clear products when filter changes
      return newFilters;
    });
  }, []);

  const handleSort = (value: string) => {
    setSort(value);
    setPage(1);
    setProducts([]); // Clear products when sort changes
  };

  const handleAddToCart = (product: Product) => {
    addToCart({
      _id: product._id,
      name: product.name,
      price: product.price,
      image_url: product.image_url,
      quantity: 1,
    });
    console.log(`Added ${product.name} to cart`);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-900 py-8">
      <div className="flex flex-col gap-8 px-4 mx-auto max-w-7xl md:flex-row">
        {/* Sidebar */}
        <div className="sticky self-start p-4 bg-gray-800 rounded-lg md:w-64 top-20">
          <h3 className="flex items-center mb-4 text-lg font-semibold">
            <Filter className="w-5 h-5 mr-2" /> Filters
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block mb-1 text-sm font-medium">Category</label>
              <select
                value={filters.category}
                onChange={(e) => updateFilter("category", e.target.value)}
                className="w-full p-2 bg-gray-700 rounded-lg focus:ring-2 focus:ring-teal-500"
              >
                <option value="">All</option>
                <option value="smart">Smart</option>
                <option value="manual">Manual</option>
              </select>
            </div>
            <div>
              <label className="block mb-1 text-sm font-medium">
                Price Range
              </label>
              <input
                type="number"
                placeholder="Min"
                value={filters.price_min}
                onChange={(e) => updateFilter("price_min", e.target.value)}
                className="w-full p-2 mb-2 bg-gray-700 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
              <input
                type="number"
                placeholder="Max"
                value={filters.price_max}
                onChange={(e) => updateFilter("price_max", e.target.value)}
                className="w-full p-2 bg-gray-700 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={filters.inStock}
                onChange={(e) => updateFilter("inStock", e.target.checked)}
                className="w-4 h-4 text-teal-500 form-checkbox"
              />
              <span>In Stock Only</span>
            </label>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={filters.new}
                onChange={(e) => updateFilter("new", e.target.checked)}
                className="w-4 h-4 text-teal-500 form-checkbox"
              />
              <span>New Arrivals</span>
            </label>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Product Catalog</h1>
            <div className="relative">
              <select
                value={sort}
                onChange={(e) => handleSort(e.target.value)}
                className="p-2 pr-8 bg-gray-700 rounded-lg appearance-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="newest">Newest</option>
                <option value="price-low">Price: Low-High</option>
                <option value="price-high">Price: High-Low</option>
              </select>
              <ChevronDown className="absolute w-4 h-4 text-gray-400 transform -translate-y-1/2 right-2 top-1/2" />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <motion.div
                key={product._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden transition-shadow bg-gray-800 rounded-lg shadow-md hover:shadow-xl"
              >
                <div className="relative">
                  <img
                    src={product.image_url || "https://placehold.co/300x300"}
                    alt={product.name}
                    className="object-cover w-full h-48"
                    onError={(e) => {
                      console.log(
                        `Image failed for ${product.name}:`,
                        product.image_url
                      );
                      e.currentTarget.src = "https://placehold.co/300x300";
                    }}
                  />
                  {product.stock < 10 && (
                    <span className="absolute px-2 py-1 text-xs font-semibold bg-orange-500 rounded top-2 right-2">
                      Low Stock
                    </span>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="mb-2 font-semibold">{product.name}</h3>
                  <p className="mb-2 font-bold text-teal-400">
                    ${product.price.toFixed(2)}
                  </p>
                  <button
                    onClick={() => handleQuickView(product._id)}
                    className="w-full py-2 text-sm transition-colors bg-gray-700 rounded-full hover:bg-gray-600"
                  >
                    Quick View
                  </button>
                  <button
                    onClick={() => handleAddToCart(product)}
                    className="w-full py-2 mt-2 font-semibold transition-colors bg-teal-500 rounded-full hover:bg-teal-600 animate-pulse"
                  >
                    Add to Cart
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
          {loading && <div className="py-4 text-center">Loading...</div>}
          {!hasMore && products.length > 0 && (
            <div className="py-4 text-center text-gray-400">
              No more products to load
            </div>
          )}
        </div>
      </div>

      {quickView && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
          onClick={() => setQuickView(null)}
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="relative w-full max-w-lg p-6 bg-gray-800 rounded-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setQuickView(null)}
              className="absolute p-1 rounded-full top-2 right-2 hover:bg-gray-700"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={quickView.image_url || "https://placehold.co/400x400"}
              alt={quickView.name}
              className="object-cover w-full h-64 mb-4 rounded-lg"
              onError={(e) => {
                console.log(
                  `Quick view image failed for ${quickView.name}:`,
                  quickView.image_url
                );
                e.currentTarget.src = "https://placehold.co/400x400";
              }}
            />
            <h3 className="mb-2 text-xl font-semibold">{quickView.name}</h3>
            <p className="mb-2 font-bold text-teal-400">
              ${quickView.price.toFixed(2)}
            </p>
            <p className="mb-4 text-gray-300">Stock: {quickView.stock}</p>
            <p className="mb-4 text-gray-400">
              Description:{" "}
              {quickView.description ||
                "Advanced smart lock with top-tier security features."}
            </p>
            <button
              onClick={() => handleAddToCart(quickView)}
              className="w-full py-2 font-semibold transition-colors bg-teal-500 rounded-full hover:bg-teal-600"
            >
              Add to Cart
            </button>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default ProductCatalogPage;
