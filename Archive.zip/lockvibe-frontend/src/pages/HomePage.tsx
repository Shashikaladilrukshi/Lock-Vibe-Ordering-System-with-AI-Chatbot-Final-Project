import React from "react";
import { motion } from "framer-motion";
import {
  Search,
  ChevronRight,
  Shield,
  Wifi,
  Battery,
  Lock,
} from "lucide-react";
import { Link } from "react-router-dom";

const featuredLocks = [
  {
    id: 1,
    name: "SmartLock Pro X1",
    price: 299.99,
    image:
      "https://images.unsplash.com/photo-1587134160474-cd3c89804b12?auto=format&fit=crop&q=80",
    features: ["Fingerprint", "WiFi", "Voice Control"],
    stock: 15,
  },
  {
    id: 2,
    name: "BioSecure 2000",
    price: 399.99,
    image:
      "https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&q=80",
    features: ["Face Recognition", "Bluetooth", "App Control"],
    stock: 8,
  },
  {
    id: 3,
    name: "Guardian Elite",
    price: 249.99,
    image:
      "https://images.unsplash.com/photo-1601143559067-f14c21e46c0b?auto=format&fit=crop&q=80",
    features: ["PIN Code", "Auto-Lock", "Break-in Alert"],
    stock: 20,
  },
  {
    id: 4,
    name: "SmartLock Air",
    price: 199.99,
    image:
      "https://images.unsplash.com/photo-1622593828624-6f7a5c7c7ca7?auto=format&fit=crop&q=80",
    features: ["Touch Control", "Long Battery", "Emergency Unlock"],
    stock: 12,
  },
];

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden">
        <div
          className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-600"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1562102122-f0d77789e68f?auto=format&fit=crop&q=80')",
            backgroundBlendMode: "overlay",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="relative flex items-center h-full px-4 mx-auto max-w-7xl">
          <div className="max-w-2xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-6 text-5xl font-bold font-display"
            >
              Lock Down Your Home
              <br />
              <span className="text-teal-400">with Smart Security</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-8 text-xl text-gray-200"
            >
              Discover our collection of advanced door locks designed for modern
              homes.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex space-x-4"
            >
              <Link
                to="/catalog" // Updated from "/shop" to "/catalog"
                className="flex items-center px-8 py-3 space-x-2 font-semibold transition-colors bg-teal-500 rounded-full hover:bg-teal-600"
              >
                <span>Shop Now</span>
                <ChevronRight className="w-5 h-5" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-800">
        <div className="px-4 mx-auto max-w-7xl">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div className="flex items-center p-6 space-x-4 bg-gray-700 rounded-lg">
              <Shield className="w-8 h-8 text-teal-500" />
              <div>
                <h3 className="mb-1 font-semibold">Advanced Security</h3>
                <p className="text-sm text-gray-300">
                  Military-grade encryption
                </p>
              </div>
            </div>
            <div className="flex items-center p-6 space-x-4 bg-gray-700 rounded-lg">
              <Wifi className="w-8 h-8 text-teal-500" />
              <div>
                <h3 className="mb-1 font-semibold">Smart Connected</h3>
                <p className="text-sm text-gray-300">
                  WiFi & Bluetooth enabled
                </p>
              </div>
            </div>
            <div className="flex items-center p-6 space-x-4 bg-gray-700 rounded-lg">
              <Battery className="w-8 h-8 text-teal-500" />
              <div>
                <h3 className="mb-1 font-semibold">Long Battery Life</h3>
                <p className="text-sm text-gray-300">
                  Up to 12 months per charge
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
