

import React, { useState } from "react";
import { useCart } from "../context/CartContext";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "../store";
import axios from "axios";
import toast from "react-hot-toast";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";


const stripePromise = loadStripe("pk_test_51RZWzwFt34VXhcXtJIBA6hY0COthlyRQMH8Kn3mHwOiADAUzW3UJaqpOygh1wAkalFAwkLXke64REY7MMqMgiWO600ePEXmnhv");


const CheckoutForm = () => {
  const { cart, clearCart } = useCart();
  const auth = useSelector((state: RootState) => state.auth);
  const navigate = useNavigate();
  const stripe = useStripe();
  const elements = useElements();
  const [shipping, setShipping] = useState({
    street: "",
    city: "",
    state: "",
    zip: "",
    country: "",
  });
  const [loading, setLoading] = useState(false);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.isAuthenticated || !auth.user?.token) {
      toast.error("Please log in to complete your order");
      navigate("/login");
      return;
    }
    if (!stripe || !elements) {
      toast.error("Stripe not loaded yet—try again.");
      return;
    }

    setLoading(true);

    try {
      // Step 1: Create the order
      const orderResponse = await axios.post(
        "http://localhost:5001/api/orders",
        {
          products: cart.map((item) => ({
            product_id: item._id,
            quantity: item.quantity,
          })),
          shipping_address: shipping,
        },
        {
          headers: { Authorization: `Bearer ${auth.user.token}` },
        }
      );
      const order = orderResponse.data.data;

      // Step 2: Create payment method with Stripe
      const cardElement = elements.getElement(CardElement);
      const { paymentMethod, error: paymentError } = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement!,
      });

      if (paymentError) {
        throw new Error(paymentError.message);
      }

      // Step 3: Process payment
      const paymentResponse = await axios.post(
        "http://localhost:5001/api/payments",
        {
          order_id: order._id,
          payment_method_id: paymentMethod.id,
        },
        {
          headers: { Authorization: `Bearer ${auth.user.token}` },
        }
      );

      if (paymentResponse.data.data.status === "succeeded") {
        clearCart();
        toast.success("Order and payment processed successfully!");
        navigate("/dashboard/orders"); // Redirect to dashboard orders page
      } else {
        toast.error("Payment pending—check your order status later.");
      }
    } catch (err: any) {
      console.error("Checkout error:", err);
      toast.error(err.response?.data?.message || err.message || "Failed to process order/payment");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-4 bg-gray-800 rounded-lg">
        <h2 className="mb-4 text-lg font-semibold">Shipping Info</h2>
        <input
          type="text"
          placeholder="Street"
          value={shipping.street}
          onChange={(e) => setShipping({ ...shipping, street: e.target.value })}
          className="w-full p-2 mb-2 bg-gray-700 rounded-lg"
          required
        />
        <input
          type="text"
          placeholder="City"
          value={shipping.city}
          onChange={(e) => setShipping({ ...shipping, city: e.target.value })}
          className="w-full p-2 mb-2 bg-gray-700 rounded-lg"
          required
        />
        <input
          type="text"
          placeholder="State"
          value={shipping.state}
          onChange={(e) => setShipping({ ...shipping, state: e.target.value })}
          className="w-full p-2 mb-2 bg-gray-700 rounded-lg"
          required
        />
        <input
          type="text"
          placeholder="ZIP Code"
          value={shipping.zip}
          onChange={(e) => setShipping({ ...shipping, zip: e.target.value })}
          className="w-full p-2 mb-2 bg-gray-700 rounded-lg"
          required
        />
        <input
          type="text"
          placeholder="Country"
          value={shipping.country}
          onChange={(e) => setShipping({ ...shipping, country: e.target.value })}
          className="w-full p-2 mb-2 bg-gray-700 rounded-lg"
          required
        />
      </div>
      <div className="p-4 bg-gray-800 rounded-lg">
        <h2 className="mb-4 text-lg font-semibold">Payment Info</h2>
        <CardElement
          className="p-2 bg-gray-700 rounded-lg"
          options={{
            style: {
              base: {
                color: "#fff",
                "::placeholder": { color: "#aab7c4" },
              },
              invalid: { color: "#ef4444" },
            },
          }}
        />
        <p className="mt-2 text-sm text-gray-400">
          Use test card: 4242 4242 4242 4242, any future date, any CVC
        </p>
      </div>
      <div className="p-4 bg-gray-800 rounded-lg">
        <h2 className="mb-4 text-lg font-semibold">Order Summary</h2>
        {cart.map((item) => (
          <div key={item._id} className="flex justify-between mb-2">
            <span>
              {item.name} (x{item.quantity})
            </span>
            <span>${(item.price * item.quantity).toFixed(2)}</span>
          </div>
        ))}
        <p className="text-xl font-bold">Total: ${total.toFixed(2)}</p>
      </div>
      <button
        type="submit"
        disabled={loading || !stripe || !elements}
        className="w-full py-2 bg-teal-500 rounded-full hover:bg-teal-600 disabled:bg-gray-600"
      >
        {loading ? "Processing..." : "Place Order"}
      </button>
    </form>
  );
};

const CheckoutPage = () => {
  const { cart } = useCart();
  const auth = useSelector((state: RootState) => state.auth);
  const navigate = useNavigate();

  if (!auth.isAuthenticated) {
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-gray-900 py-8">
        <div className="px-4 mx-auto max-w-7xl">
          <p className="text-gray-400">
            Please <Link to="/login" className="text-teal-500">log in</Link> to checkout.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-900 py-8">
      <div className="px-4 mx-auto max-w-7xl">
        <h1 className="mb-6 text-2xl font-bold">Checkout</h1>
        {cart.length === 0 ? (
          <p className="text-gray-400">
            Your cart is empty. <Link to="/catalog" className="text-teal-500">Shop now!</Link>
          </p>
        ) : (
          <Elements stripe={stripePromise}>
            <CheckoutForm />
          </Elements>
        )}
      </div>
    </div>
  );
};

export default CheckoutPage;
