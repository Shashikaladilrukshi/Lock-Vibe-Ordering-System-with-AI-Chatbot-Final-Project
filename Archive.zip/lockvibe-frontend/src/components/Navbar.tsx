import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Lock, ShoppingCart, Sun, Moon, User, LogOut } from "lucide-react";
import { toggleDarkMode } from "../store/slices/uiSlice";
import { logout } from "../store/slices/authSlice";
import { RootState } from "../store";
import toast from "react-hot-toast";
import { useCart } from "../context/CartContext";

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const auth = useSelector((state: RootState) => state.auth);
  const { cart } = useCart(); // Access cart from CartContext

  // Calculate total number of items in the cart
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleLogout = () => {
    dispatch(logout());
    localStorage.removeItem("token");
    toast.success("Logged out successfully");
    navigate("/");
  };

  return (
    <nav className="sticky top-0 z-50 bg-gray-800/80 backdrop-blur-md">
      <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Lock className="w-8 h-8 text-teal-500" />
            <span className="text-xl font-bold text-transparent bg-gradient-to-r from-teal-500 to-blue-600 bg-clip-text">
              SecureLock
            </span>
          </Link>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => dispatch(toggleDarkMode())}
              className="p-2 transition-colors rounded-full hover:bg-gray-700"
            >
              <Sun className="w-5 h-5" />
            </button>

            {auth.isAuthenticated ? (
              <>
                <Link
                  to="/cart"
                  className="relative p-2 transition-colors rounded-full hover:bg-gray-700"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {cartItemCount > 0 && (
                    <span className="absolute top-0 right-0 flex items-center justify-center w-5 h-5 text-xs bg-red-500 rounded-full">
                      {cartItemCount}
                    </span>
                  )}
                </Link>
                <Link
                  to={auth.user?.role === "admin" ? "/admin" : "/dashboard"}
                  className="p-2 transition-colors rounded-full hover:bg-gray-700"
                >
                  <User className="w-5 h-5" />
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center px-4 py-2 space-x-2 text-sm font-medium text-red-500 transition-colors rounded-lg bg-red-500/10 hover:bg-red-500/20"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Link
                  to="/login"
                  className="px-4 py-2 text-sm font-medium transition-colors rounded-lg hover:bg-gray-700"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="px-4 py-2 text-sm font-medium text-white transition-colors bg-teal-500 rounded-lg hover:bg-teal-600"
                >
                  Register
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;