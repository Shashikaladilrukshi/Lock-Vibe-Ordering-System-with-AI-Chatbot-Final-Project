import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send } from "lucide-react";
import { toggleChatbot, addMessage } from "../store/slices/uiSlice";
import { RootState } from "../store";
import axios from "axios";

const ChatbotWidget = () => {
  const dispatch = useDispatch();
  const auth = useSelector((state: RootState) => state.auth);
  const isOpen = useSelector((state: RootState) => state.ui.isChatbotOpen);
  const messages = useSelector((state: RootState) => state.ui.messages);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (!input.trim()) return;

    // Check authentication
    if (!auth.isAuthenticated || !auth.user?.token) {
      dispatch(
        addMessage({
          text: "Please log in to use the chatbot!",
          sender: "bot",
        })
      );
      return;
    }

    // Add user message immediately
    dispatch(addMessage({ text: input, sender: "user" }));
    const userMessage = input;
    setInput("");

    try {
      const response = await axios.post(
        "http://localhost:5001/api/chat",
        { message: userMessage },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${auth.user.token}`,
          },
        }
      );

      if (response.data?.data?.response) {
        dispatch(
          addMessage({
            text: response.data.data.response,
            sender: "bot",
          })
        );
      }
    } catch (error: any) {
      console.error("Chatbot error:", error);

      if (error.response?.status === 401) {
        // Handle expired token
        dispatch(logout());
        localStorage.removeItem("token");
        navigate("/login");
        toast.error("Session expired. Please log in again.");
      } else {
        dispatch(
          addMessage({
            text: "Sorry, I'm having trouble connecting right now. Try again later!",
            sender: "bot",
          })
        );
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSend();
  };

  return (
    <>
      <button
        onClick={() => dispatch(toggleChatbot())}
        className="fixed z-50 p-4 transition-colors bg-teal-500 rounded-full shadow-lg bottom-4 right-4 hover:bg-teal-600"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-20 right-4 w-96 h-[500px] bg-gray-800 rounded-lg shadow-xl z-50 overflow-hidden"
          >
            <div className="flex items-center justify-between p-4 border-b border-gray-700">
              <h3 className="text-lg font-semibold">AI Assistant</h3>
              <button
                onClick={() => dispatch(toggleChatbot())}
                className="p-1 transition-colors rounded-full hover:bg-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 h-[calc(100%-130px)] overflow-y-auto space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.sender === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.sender === "user"
                        ? "bg-teal-500 text-white"
                        : "bg-gray-700 text-gray-100"
                    }`}
                  >
                    {message.text}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-gray-700">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 bg-gray-700 rounded-full focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
                <button
                  onClick={handleSend}
                  className="p-2 transition-colors bg-teal-500 rounded-full hover:bg-teal-600"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatbotWidget;
