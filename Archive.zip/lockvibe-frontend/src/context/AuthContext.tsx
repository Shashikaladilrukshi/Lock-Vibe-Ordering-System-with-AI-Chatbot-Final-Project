// import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
// import axios from 'axios';

// interface User {
//   id: string;
//   name: string;
//   email: string;
//   role: string;
// }

// interface AuthContextType {
//   user: User | null;
//   token: string | null;
//   login: (email: string, password: string) => Promise<void>;
//   logout: () => void;
//   register: (name: string, email: string, password: string, address?: any) => Promise<void>;
// }

// const AuthContext = createContext<AuthContextType | undefined>(undefined);

// export const AuthProvider = ({ children }: { children: ReactNode }) => {
//   const [user, setUser] = useState<User | null>(null);
//   const [token, setToken] = useState<string | null>(localStorage.getItem('token'));

//   useEffect(() => {
//     if (token) {
//       axios.get('http://localhost:5001/api/users/me', { headers: { Authorization: `Bearer ${token}` } })
//         .then((res) => setUser(res.data.data))
//         .catch(() => logout());
//     }
//   }, [token]);

//   const login = async (email: string, password: string) => {
//     const res = await axios.post('http://localhost:5001/api/users/login', { email, password });
//     const { token } = res.data.data;
//     localStorage.setItem('token', token);
//     setToken(token);
//   };

//   const register = async (name: string, email: string, password: string, address?: any) => {
//     const res = await axios.post('http://localhost:5001/api/users/register', { name, email, password, address });
//     const { token } = res.data.data;
//     localStorage.setItem('token', token);
//     setToken(token);
//   };

//   const logout = () => {
//     localStorage.removeItem('token');
//     setToken(null);
//     setUser(null);
//   };

//   return (
//     <AuthContext.Provider value={{ user, token, login, logout, register }}>
//       {children}
//     </AuthContext.Provider>
//   );
// };

// export const useAuth = () => {
//   const context = useContext(AuthContext);
//   if (!context) throw new Error('useAuth must be used within an AuthProvider');
//   return context;
// };



import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string, address?: any) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      axios.get('http://localhost:5001/api/users/me', { headers: { Authorization: `Bearer ${token}` } })
        .then((res) => {
          console.log("Fetched user data:", res.data); // Debug log
          setUser({
            id: res.data.data._id,
            name: res.data.data.name,
            email: res.data.data.email,
            role: res.data.data.role
          });
        })
        .catch((err) => {
          console.error("Failed to fetch user:", err.response?.data || err);
          logout(); // Clear token if /me fails
        });
    }
  }, [token]);

  const login = async (email: string, password: string) => {
    const res = await axios.post('http://localhost:5001/api/users/login', { email, password });
    const { token } = res.data.data;
    localStorage.setItem('token', token);
    setToken(token);
  };

  const register = async (name: string, email: string, password: string, address?: any) => {
    const res = await axios.post('http://localhost:5001/api/users/register', { name, email, password, address });
    const { token } = res.data.data;
    localStorage.setItem('token', token);
    setToken(token);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};